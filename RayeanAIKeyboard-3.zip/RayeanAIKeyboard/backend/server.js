// Rayean AI Keyboard — Node.js runner for the AI backend.
//
// Runs the same code as the Cloudflare Worker (worker.js) on Node 18+,
// for a VPS, Docker, Render, Railway, Fly.io, etc.
//
//   ANTHROPIC_API_KEY=sk-ant-... APP_TOKEN=... node server.js
//
// See worker.js for all environment variables.

import http from "node:http";
import worker from "./worker.js";

const PORT = Number(process.env.PORT || 8787);
const MAX_BODY_BYTES = 64 * 1024;

const server = http.createServer(async (req, res) => {
  try {
    const chunks = [];
    let size = 0;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        res.writeHead(413, { "content-type": "application/json" });
        res.end(JSON.stringify({ error: "Request too large" }));
        return;
      }
      chunks.push(chunk);
    }
    const headers = new Headers();
    for (const [k, v] of Object.entries(req.headers)) {
      if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(", ") : v);
    }
    if (!headers.has("x-forwarded-for")) headers.set("x-forwarded-for", req.socket.remoteAddress || "");
    const hasBody = req.method !== "GET" && req.method !== "HEAD";
    const request = new Request(`http://localhost${req.url}`, {
      method: req.method,
      headers,
      body: hasBody ? Buffer.concat(chunks) : undefined,
    });
    const response = await worker.fetch(request, process.env);
    const out = Buffer.from(await response.arrayBuffer());
    res.writeHead(response.status, Object.fromEntries(response.headers));
    res.end(out);
  } catch (err) {
    console.error(`${req.method} ${req.url} -> 500: ${err.message}`);
    if (!res.headersSent) res.writeHead(500, { "content-type": "application/json" });
    res.end(JSON.stringify({ error: "Internal server error" }));
  }
});

server.listen(PORT, () => {
  console.log(`Rayean AI backend listening on :${PORT}`);
});
