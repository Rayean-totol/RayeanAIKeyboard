// Offline tests: runs the real backend code against a mock AI provider.
// Covers the Node runner (server.js) and the Cloudflare Worker module (worker.js)
// with all three providers. Usage: npm test
import http from "node:http";
import { spawn } from "node:child_process";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import path from "node:path";
import worker from "../worker.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const received = [];

function replyFor(input) {
  if (input.includes("I am go market")) return "I am going to the market.";
  if (input.includes("ami ajke dokane jabo")) return "আমি আজকে দোকানে যাব।";
  if (input.includes("How are you")) return "\"আপনি কেমন আছেন?\"";
  return "?";
}

// ---- mock AI providers (Claude, OpenAI, Gemini wire formats) ----
const mock = http.createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    const j = JSON.parse(body);
    received.push({ url: req.url, headers: req.headers, json: j });
    const send = (status, obj) => {
      res.writeHead(status, { "content-type": "application/json" });
      res.end(JSON.stringify(obj));
    };
    if (req.url === "/v1/messages") {
      if (req.headers["x-api-key"] === "bad-key") return send(401, { error: { type: "authentication_error", message: "invalid x-api-key" } });
      return send(200, { content: [{ type: "text", text: replyFor(j.messages[0].content) }] });
    }
    if (req.url === "/v1/chat/completions") {
      return send(200, { choices: [{ message: { role: "assistant", content: replyFor(j.messages[1].content) } }] });
    }
    if (req.url.startsWith("/v1beta/models/")) {
      return send(200, {
        candidates: [{ content: { parts: [{ text: "thinking...", thought: true }, { text: replyFor(j.contents[0].parts[0].text) }] } }],
      });
    }
    send(404, { error: { message: "unknown" } });
  });
});
await new Promise((r) => mock.listen(0, r));
const MOCK = `http://127.0.0.1:${mock.address().port}`;

// ---- 1) Node runner (server.js) with Claude ----
const port = 18000 + Math.floor(Math.random() * 1000);
const server = spawn(process.execPath, [path.join(here, "..", "server.js")], {
  env: { ...process.env, PORT: String(port), ANTHROPIC_API_KEY: "test-key", ANTHROPIC_BASE_URL: MOCK, APP_TOKEN: "secret-token" },
  stdio: ["ignore", "pipe", "pipe"],
});
let logs = "";
server.stdout.on("data", (d) => (logs += d));
server.stderr.on("data", (d) => (logs += d));
await new Promise((r) => setTimeout(r, 700));

const base = `http://127.0.0.1:${port}`;
const auth = { Authorization: "Bearer secret-token", "content-type": "application/json" };
const post = (p, body, headers = auth) => fetch(base + p, { method: "POST", headers, body: JSON.stringify(body) });

try {
  let r = await fetch(base + "/health", { headers: auth });
  assert.equal(r.status, 200);
  let h = await r.json();
  assert.equal(h.ok, true);
  assert.equal(h.configured, true);
  assert.equal(h.provider, "anthropic");

  r = await post("/v1/fix", { text: "x" }, { "content-type": "application/json" });
  assert.equal(r.status, 401, "token required");

  r = await post("/v1/fix", { text: "I am go market", keyboard_language: "en" });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).text, "I am going to the market.");

  r = await post("/v1/fix", { text: "ami ajke dokane jabo", keyboard_language: "bn" });
  assert.equal((await r.json()).text, "আমি আজকে দোকানে যাব।");

  r = await post("/v1/translate", { text: "How are you?", source: "en", target: "bn" });
  assert.equal((await r.json()).text, "আপনি কেমন আছেন?");
  assert.match(received.at(-1).json.system, /from English to Bengali/);

  r = await post("/v1/translate", { text: "hi", source: "en", target: "en" });
  assert.equal(r.status, 400);
  r = await post("/v1/fix", { text: "" });
  assert.equal(r.status, 400);
  r = await post("/v1/fix", { text: "a".repeat(4001) });
  assert.equal(r.status, 413);

  const first = received[0];
  assert.equal(first.headers["x-api-key"], "test-key");
  assert.equal(first.headers["anthropic-version"], "2023-06-01");
  assert.equal(first.json.model, "claude-haiku-4-5-20251001");

  assert.ok(!logs.includes("I am go market"), "user text leaked into logs");
  assert.ok(!logs.includes("ami ajke"), "user text leaked into logs");
  console.log("✓ Node runner + Claude");
} finally {
  server.kill();
}

// ---- 2) Cloudflare Worker module, called directly ----
const call = (env, p, body, token) =>
  worker.fetch(
    new Request("https://rayean.example.workers.dev" + p, {
      method: body ? "POST" : "GET",
      headers: { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    }),
    env,
  );

// OpenAI
let r = await call({ OPENAI_API_KEY: "o-key", OPENAI_BASE_URL: MOCK }, "/v1/fix", { text: "I am go market" });
assert.equal(r.status, 200);
assert.equal((await r.json()).text, "I am going to the market.");
assert.equal(received.at(-1).headers.authorization, "Bearer o-key");
assert.equal(received.at(-1).json.model, "gpt-5-mini");
console.log("✓ Worker + OpenAI");

// Gemini (thought parts are skipped)
r = await call({ GEMINI_API_KEY: "g-key", GEMINI_BASE_URL: MOCK, AI_MODEL: "my-model" }, "/v1/fix", { text: "ami ajke dokane jabo" });
assert.equal(r.status, 200);
assert.equal((await r.json()).text, "আমি আজকে দোকানে যাব।");
assert.equal(received.at(-1).url, "/v1beta/models/my-model:generateContent");
assert.equal(received.at(-1).headers["x-goog-api-key"], "g-key");
console.log("✓ Worker + Gemini");

// No key configured -> clear 503, health says not configured
r = await call({}, "/v1/fix", { text: "hello" });
assert.equal(r.status, 503);
assert.match((await r.json()).error, /ANTHROPIC_API_KEY/);
r = await call({}, "/health");
assert.equal((await r.json()).configured, false);
console.log("✓ Missing key reported clearly");

// Wrong provider key -> 502 with a helpful message
r = await call({ ANTHROPIC_API_KEY: "bad-key", ANTHROPIC_BASE_URL: MOCK }, "/v1/fix", { text: "hello" });
assert.equal(r.status, 502);
assert.match((await r.json()).error, /Claude error 401 — check the API key secret/);
console.log("✓ Provider errors passed through");

// Unreachable provider -> 502, not a crash
r = await call({ ANTHROPIC_API_KEY: "k", ANTHROPIC_BASE_URL: "http://127.0.0.1:9" }, "/v1/fix", { text: "hello" });
assert.equal(r.status, 502);
assert.match((await r.json()).error, /Could not reach the AI provider/);
console.log("✓ Unreachable provider handled");

// App token enforced in the Worker too
r = await call({ ANTHROPIC_API_KEY: "k", APP_TOKEN: "t" }, "/v1/fix", { text: "hello" }, "wrong");
assert.equal(r.status, 401);
console.log("✓ App token enforced");

mock.close();
console.log("All backend tests passed ✓");
