# Rayean AI backend

AI Fix (and the optional AI translation engine) need a language model. The keyboard **never** contains an AI API key: it calls this backend, and the backend calls the AI provider with a key stored as a server secret.

`worker.js` is one file that runs on **Cloudflare Workers** (free, can be set up entirely from a phone browser) and on **Node.js 18+** (`server.js`).

## Option A — Cloudflare Workers (recommended, works from a phone)

1. Sign up / log in at **dash.cloudflare.com**.
2. Open **Workers & Pages** → **Create application** → **Start with Hello World!** → name it `rayean-ai` → **Deploy**.
3. Tap **Edit code**, delete everything in `worker.js`, paste the whole content of `backend/worker.js`, then tap **Deploy**.
4. Go back to the Worker → **Settings** → **Variables and Secrets** → **Add**:
   - Type **Secret**, name `ANTHROPIC_API_KEY`, value = your Claude API key (from platform.claude.com). → **Deploy**
   - Add another: type **Secret**, name `APP_TOKEN`, value = any long random password you make up. → **Deploy**
5. Your backend URL is shown on the Worker page, like `https://rayean-ai.YOUR-NAME.workers.dev`. Open `https://rayean-ai.YOUR-NAME.workers.dev/health` in the browser: it asks for the token (401) — that means it is running and protected.
6. On the phone: keyboard ⚙ **Settings** → **Backend API URL** = that URL, **App token** = the same `APP_TOKEN` → **Test AI Fix**.

Cloudflare's free plan includes 100,000 requests per day.

## Option B — Node.js server (VPS, Docker, Render, Railway…)

```bash
cd backend
export ANTHROPIC_API_KEY=sk-ant-...
export APP_TOKEN=$(openssl rand -hex 24)
npm start        # listens on :8787 — put it behind HTTPS
npm test         # offline tests with a mock AI provider
```

Docker: `docker build -t rayean-ai-backend . && docker run -p 8787:8787 -e ANTHROPIC_API_KEY=... -e APP_TOKEN=... rayean-ai-backend`

## Settings (secrets / environment variables)

| Name | Required | Meaning |
|---|---|---|
| `ANTHROPIC_API_KEY` | one key is required | Claude (default provider, model `claude-haiku-4-5-20251001`) |
| `OPENAI_API_KEY` | or | OpenAI (default model `gpt-5-mini`) |
| `GEMINI_API_KEY` | or | Google Gemini (default model `gemini-3.8-flash`) |
| `AI_PROVIDER` | no | `anthropic`, `openai` or `gemini` — only needed if you set more than one key |
| `AI_MODEL` | no | Use a different model ID from your provider |
| `APP_TOKEN` | strongly recommended | Without it, anyone who finds your URL can use your AI quota |

Model names change over time. If AI Fix shows an error like "error 404 — check AI_MODEL", set `AI_MODEL` to a current model ID from your provider's model list.

## API

| Method | Path | Body | Response |
|---|---|---|---|
| `GET` | `/health` | – | `{"ok":true,"configured":true,"provider":"anthropic","model":"…"}` |
| `POST` | `/v1/fix` | `{"text":"I am go market","keyboard_language":"en"}` | `{"text":"I am going to the market."}` |
| `POST` | `/v1/translate` | `{"text":"…","source":"bn","target":"en"}` | `{"text":"…"}` |

Errors come back as `{"error":"message"}` with a 4xx/5xx status; the keyboard shows that message.

## Privacy

- The keyboard never sends password, PIN, OTP, card-number, number/phone or incognito fields, and refuses text that looks like a card number or one-time code.
- This backend never logs or stores the text; only error messages are logged.
