package com.rayean.aikeyboard

import com.rayean.aikeyboard.data.BackendUrl
import com.rayean.aikeyboard.data.KeyboardLanguage
import com.rayean.aikeyboard.ime.TextDeletion
import com.rayean.aikeyboard.keyboard.KeyLabels
import com.rayean.aikeyboard.keyboard.KeyType
import com.rayean.aikeyboard.keyboard.KeyboardMode
import com.rayean.aikeyboard.keyboard.Layouts
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.text.Normalizer

class BanglaAndBackendTest {

    // ---------------- Bangla key labels ----------------

    @Test
    fun vowelSignsGetAnInvisibleBase() {
        for (mark in listOf("া", "ি", "ী", "ু", "ূ", "ৃ", "ে", "ৈ", "ো", "ৌ", "্", "ঁ", "ং", "ঃ")) {
            assertEquals(KeyLabels.NBSP + mark, KeyLabels.display(mark))
        }
    }

    @Test
    fun lettersAndDigitsAreDrawnAsIs() {
        for (s in listOf("ক", "আ", "য়", "১", "a", "ض", "?১২৩", "ZWJ")) assertEquals(s, KeyLabels.display(s))
    }

    @Test
    fun banglaKeysTypeNormalizedUnicode() {
        for (numberRow in listOf(true, false)) {
            val keys = Layouts.build(KeyboardLanguage.BANGLA, KeyboardMode.ALPHA, numberRow).rows.flatten()
            keys.filter { it.type == KeyType.CHAR }.flatMap { listOfNotNull(it.output, it.shiftOutput, it.longPress) }.forEach {
                assertTrue("not NFC: $it", Normalizer.isNormalized(it, Normalizer.Form.NFC))
            }
            assertTrue(keys.any { it.output == "য়" }) // য়
            assertTrue(keys.any { it.output == "ঁ" })            // chandrabindu has its own key
        }
    }

    // ---------------- Backspace ----------------

    @Test
    fun backspaceLengths() {
        assertEquals(1, TextDeletion.lengthToDelete("abc"))
        assertEquals(4, TextDeletion.lengthToDelete("ok 👍🏽"))          // emoji + skin tone
        assertEquals(1, TextDeletion.lengthToDelete("কি"))              // only the vowel sign
        assertEquals(1, TextDeletion.lengthToDelete("ক্ষ"))             // one step of a conjunct
        assertEquals(2, TextDeletion.lengthToDelete("য়"))    // য় in one press
        assertEquals(1, TextDeletion.lengthToDelete("بَ"))               // harakah only
        assertEquals(1, TextDeletion.lengthToDelete("ok َ"))       // lone harakah, keep the space
        assertEquals(0, TextDeletion.lengthToDelete(""))
    }

    // ---------------- Backend URL ----------------

    @Test
    fun backendUrlIsCleanedUp() {
        assertEquals("https://rayean-ai.me.workers.dev", BackendUrl.normalize("rayean-ai.me.workers.dev"))
        assertEquals("https://rayean-ai.me.workers.dev", BackendUrl.normalize(" https://rayean-ai.me.workers.dev/ "))
        assertEquals("https://x.dev", BackendUrl.normalize("https://x.dev/health"))
        assertEquals("https://x.dev", BackendUrl.normalize("https://x.dev/v1/fix"))
        assertEquals("http://10.0.2.2:8787", BackendUrl.normalize("http://10.0.2.2:8787/"))
        assertEquals("", BackendUrl.normalize("   "))
        assertEquals("rayean-ai.me.workers.dev", BackendUrl.host("https://rayean-ai.me.workers.dev/health"))
    }

    @Test
    fun backendUrlValidation() {
        assertTrue(BackendUrl.isValid("rayean-ai.me.workers.dev"))
        assertTrue(BackendUrl.isValid("http://localhost:8787"))
        assertFalse(BackendUrl.isValid("not a url"))
        assertFalse(BackendUrl.isValid("ftp://x.dev"))
        assertFalse(BackendUrl.isValid(""))
    }
}
