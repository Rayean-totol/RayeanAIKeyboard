package com.rayean.aikeyboard.ime

import android.content.Intent
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.rayean.aikeyboard.R
import com.rayean.aikeyboard.ai.AiBackendClient
import com.rayean.aikeyboard.ai.AiMessages
import com.rayean.aikeyboard.data.KeyboardLanguage
import com.rayean.aikeyboard.data.Prefs
import com.rayean.aikeyboard.emoji.EmojiPanel
import com.rayean.aikeyboard.keyboard.EnterStyle
import com.rayean.aikeyboard.keyboard.Key
import com.rayean.aikeyboard.keyboard.KeyType
import com.rayean.aikeyboard.keyboard.KeyboardMode
import com.rayean.aikeyboard.keyboard.KeyboardTheme
import com.rayean.aikeyboard.keyboard.KeyboardView
import com.rayean.aikeyboard.keyboard.Layouts
import com.rayean.aikeyboard.keyboard.ShiftState
import com.rayean.aikeyboard.privacy.PrivacyGuard
import com.rayean.aikeyboard.settings.SettingsActivity
import com.rayean.aikeyboard.translate.TranslationDirection
import com.rayean.aikeyboard.translate.TranslationService
import com.rayean.aikeyboard.voice.MicPermissionActivity
import com.rayean.aikeyboard.voice.VoiceInputController
import com.rayean.aikeyboard.voice.VoicePermission
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Rayean AI Keyboard — the Android system keyboard (InputMethodService).
 *
 * Enabled in Settings → System → Keyboard, then usable in any app (WhatsApp, Messenger,
 * Facebook, SMS, browsers, Notes, …). All text goes into the app through the
 * InputConnection the system hands to this service.
 */
class RayeanImeService : InputMethodService(),
    KeyboardView.Listener,
    EmojiPanel.Callback,
    VoiceInputController.Callback,
    KeyboardToolbar.Listener {

    private lateinit var prefs: Prefs
    private lateinit var aiClient: AiBackendClient
    private lateinit var translation: TranslationService
    private lateinit var voice: VoiceInputController

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var aiJob: Job? = null

    // Views (recreated by onCreateInputView)
    private var rootView: View? = null
    private var keyboardView: KeyboardView? = null
    private var emojiPanel: EmojiPanel? = null
    private var toolbar: KeyboardToolbar? = null

    // Keyboard state
    private var theme = KeyboardTheme.LIGHT
    private var language = KeyboardLanguage.ENGLISH
    private var mode = KeyboardMode.ALPHA
    private var shift = ShiftState.OFF
    private var autoShifted = false
    private var lastShiftTap = 0L
    private var enterStyle = EnterStyle.RETURN
    private var privacy = PrivacyGuard.Level.NORMAL
    private var inputSession = 0

    // Cached settings
    private var numberRow = true
    private var vibrationOn = true
    private var soundOn = false

    // Voice / AI state
    private var voiceComposing = false
    private var voicePrefix = ""
    private var voiceCapitalize = false
    private var lastUndo: EditorText.Undo? = null

    private var vibrator: Vibrator? = null
    private var audio: AudioManager? = null

    // ================================================================ lifecycle

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        aiClient = AiBackendClient(prefs)
        translation = TranslationService(prefs, aiClient)
        voice = VoiceInputController(this, this)
        audio = getSystemService(AudioManager::class.java)
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Vibrator::class.java)
        }
    }

    override fun onCreateInputView(): View {
        val root = layoutInflater.inflate(R.layout.keyboard_root, null)
        val kv = root.findViewById<KeyboardView>(R.id.keyboard_view)
        kv.listener = this
        keyboardView = kv

        val panel = EmojiPanel(this, this)
        panel.visibility = View.GONE
        root.findViewById<FrameLayout>(R.id.keyboard_area).addView(
            panel,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        emojiPanel = panel
        toolbar = KeyboardToolbar(root, this)

        // Keep keys above the gesture / navigation bar on edge-to-edge devices.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            v.updatePadding(bottom = nav.bottom)
            insets
        }
        rootView = root
        applySettings()
        return root
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        if (!restarting) inputSession++
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        applySettings()
        privacy = PrivacyGuard.classify(info)
        enterStyle = enterStyleFor(info)
        val fieldMode = modeFor(info)
        if (!restarting || mode == KeyboardMode.NUMBER || mode == KeyboardMode.PHONE || fieldMode != KeyboardMode.ALPHA) {
            mode = fieldMode
            shift = ShiftState.OFF
            autoShifted = false
            hideEmoji()
            toolbar?.showActions()
            lastUndo = null
        }
        toolbar?.setFieldState(privacy, prefs.aiEnabled)
        refreshKeyboard()
        updateAutoShift()

        if (VoicePermission.consumePendingStart() && VoicePermission.isGranted(this) &&
            privacy != PrivacyGuard.Level.PRIVATE
        ) {
            startVoice()
        }
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        if (voice.isListening) voice.cancel()
        finishVoiceComposing()
        aiJob?.cancel()
        keyboardView?.cancelTouches()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int,
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        if (!voice.isListening) updateAutoShift()
    }

    override fun onDestroy() {
        scope.cancel()
        voice.destroy()
        translation.close()
        super.onDestroy()
    }

    // ================================================================ settings & layout

    private fun applySettings() {
        theme = KeyboardTheme.resolve(this, prefs.themeId)
        numberRow = prefs.showNumberRow
        vibrationOn = prefs.vibrationEnabled
        soundOn = prefs.soundEnabled
        language = prefs.currentLanguage // always one of the enabled languages

        rootView?.setBackgroundColor(theme.background)
        keyboardView?.let {
            it.theme = theme
            it.heightScale = prefs.heightScale
        }
        emojiPanel?.applyTheme(theme)
        toolbar?.applyTheme(theme)
    }

    private fun refreshKeyboard() {
        val kv = keyboardView ?: return
        kv.keyboardLayout = Layouts.build(language, mode, numberRow)
        kv.shiftState = shift
        kv.spaceLabel = language.displayName
        kv.languageKeyLabel = language.keyLabel
        kv.enterStyle = enterStyle
    }

    private fun modeFor(info: EditorInfo): KeyboardMode = when (info.inputType and InputType.TYPE_MASK_CLASS) {
        InputType.TYPE_CLASS_NUMBER, InputType.TYPE_CLASS_DATETIME -> KeyboardMode.NUMBER
        InputType.TYPE_CLASS_PHONE -> KeyboardMode.PHONE
        else -> KeyboardMode.ALPHA
    }

    private fun enterStyleFor(info: EditorInfo): EnterStyle {
        if (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION != 0) return EnterStyle.RETURN
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> EnterStyle.GO
            EditorInfo.IME_ACTION_SEARCH -> EnterStyle.SEARCH
            EditorInfo.IME_ACTION_SEND -> EnterStyle.SEND
            EditorInfo.IME_ACTION_NEXT -> EnterStyle.NEXT
            EditorInfo.IME_ACTION_DONE -> EnterStyle.DONE
            EditorInfo.IME_ACTION_PREVIOUS -> EnterStyle.PREVIOUS
            else -> EnterStyle.RETURN
        }
    }

    private fun setMode(newMode: KeyboardMode) {
        mode = newMode
        if (newMode != KeyboardMode.ALPHA) {
            shift = ShiftState.OFF
            autoShifted = false
        }
        refreshKeyboard()
        updateAutoShift()
    }

    // ================================================================ key handling

    override fun onKeyDown(key: Key) {
        if (vibrationOn) vibrate()
        if (soundOn) {
            val fx = when (key.type) {
                KeyType.BACKSPACE -> AudioManager.FX_KEYPRESS_DELETE
                KeyType.SPACE -> AudioManager.FX_KEYPRESS_SPACEBAR
                KeyType.ENTER -> AudioManager.FX_KEYPRESS_RETURN
                else -> AudioManager.FX_KEYPRESS_STANDARD
            }
            audio?.playSoundEffect(fx, -1f)
        }
    }

    override fun onKey(key: Key) {
        when (key.type) {
            KeyType.CHAR -> {
                val shifted = mode == KeyboardMode.ALPHA && shift != ShiftState.OFF
                commitTyped(key.outputFor(shifted))
            }
            KeyType.SPACE -> commitTyped(" ")
            KeyType.BACKSPACE -> handleBackspace()
            KeyType.ENTER -> handleEnter()
            KeyType.SHIFT -> handleShift()
            KeyType.MODE_SYMBOLS -> setMode(KeyboardMode.SYMBOLS)
            KeyType.MODE_SYMBOLS_2 -> setMode(KeyboardMode.SYMBOLS_2)
            KeyType.MODE_ALPHA -> setMode(KeyboardMode.ALPHA)
            KeyType.LANGUAGE -> switchLanguage()
            KeyType.EMOJI -> showEmoji()
        }
    }

    override fun onKeyRepeat(key: Key) {
        if (key.type == KeyType.BACKSPACE) handleBackspace()
    }

    override fun onKeyLongPress(key: Key): Boolean = when {
        key.type == KeyType.CHAR && key.longPress != null -> {
            commitTyped(key.longPress)
            true
        }
        key.type == KeyType.SPACE || key.type == KeyType.LANGUAGE -> {
            showInputMethodPicker()
            true
        }
        else -> false
    }

    /** Commits typed text and handles one-shot Shift and auto-capitalization. */
    private fun commitTyped(text: String) {
        val ic = currentInputConnection ?: return
        stopVoiceForTyping()
        ic.commitText(text, 1)
        if (shift == ShiftState.ON) {
            shift = ShiftState.OFF
            autoShifted = false
            keyboardView?.shiftState = shift
        }
        updateAutoShift()
    }

    private fun handleBackspace() {
        val ic = currentInputConnection ?: return
        if (voiceComposing) {
            // Backspace during dictation discards the words still being recognized.
            if (voice.isListening) voice.cancel()
            ic.setComposingText("", 1)
            ic.finishComposingText()
            voiceComposing = false
            return
        }
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            val before = ic.getTextBeforeCursor(32, 0)
            if (before.isNullOrEmpty()) {
                // Let the app handle it (e.g. deleting a chip, or nothing to delete).
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            } else {
                ic.deleteSurroundingText(TextDeletion.lengthToDelete(before), 0)
            }
        }
        updateAutoShift()
    }

    private fun handleEnter() {
        val ic = currentInputConnection ?: return
        stopVoiceForTyping()
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noEnterAction = info != null && (info.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun handleShift() {
        if (mode != KeyboardMode.ALPHA) return
        val now = SystemClock.uptimeMillis()
        shift = when (shift) {
            ShiftState.OFF -> ShiftState.ON
            ShiftState.ON -> if (!autoShifted && now - lastShiftTap < DOUBLE_TAP_MS) ShiftState.LOCKED else ShiftState.OFF
            ShiftState.LOCKED -> ShiftState.OFF
        }
        autoShifted = false
        lastShiftTap = now
        keyboardView?.shiftState = shift
    }

    private fun updateAutoShift() {
        if (shift == ShiftState.LOCKED) return
        val want = shouldAutoCapitalize()
        if (want && shift == ShiftState.OFF) {
            shift = ShiftState.ON
            autoShifted = true
        } else if (!want && shift == ShiftState.ON && autoShifted) {
            shift = ShiftState.OFF
            autoShifted = false
        }
        keyboardView?.shiftState = shift
    }

    private fun shouldAutoCapitalize(): Boolean {
        if (!prefs.autoCapitalize || mode != KeyboardMode.ALPHA || language != KeyboardLanguage.ENGLISH) return false
        val info = currentInputEditorInfo ?: return false
        val type = info.inputType
        if (type and InputType.TYPE_MASK_CLASS != InputType.TYPE_CLASS_TEXT) return false
        if ((type and InputType.TYPE_MASK_VARIATION) in NO_CAPS_VARIATIONS) return false
        val ic = currentInputConnection ?: return false
        val capFlags = InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
            InputType.TYPE_TEXT_FLAG_CAP_WORDS or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        val req = if (type and capFlags != 0) type else InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        return ic.getCursorCapsMode(req) != 0
    }

    private fun switchLanguage() {
        val langs = prefs.enabledLanguages
        if (langs.size <= 1) {
            showInputMethodPicker()
            return
        }
        language = langs[(langs.indexOf(language) + 1) % langs.size]
        prefs.currentLanguage = language
        if (mode == KeyboardMode.SYMBOLS || mode == KeyboardMode.SYMBOLS_2) mode = KeyboardMode.ALPHA
        shift = ShiftState.OFF
        autoShifted = false
        refreshKeyboard()
        updateAutoShift()
    }

    private fun showInputMethodPicker() {
        getSystemService(InputMethodManager::class.java)?.showInputMethodPicker()
    }

    private fun vibrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val effect = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
        } else {
            VibrationEffect.createOneShot(15L, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        runCatching { v.vibrate(effect) }
    }

    // ================================================================ emoji

    private fun showEmoji() {
        val kv = keyboardView ?: return
        val panel = emojiPanel ?: return
        // The key area keeps its size (INVISIBLE), so the keyboard height does not jump.
        kv.visibility = View.INVISIBLE
        panel.visibility = View.VISIBLE
        panel.onShown()
    }

    private fun hideEmoji() {
        emojiPanel?.visibility = View.GONE
        keyboardView?.visibility = View.VISIBLE
    }

    override fun onEmojiSelected(emoji: String) {
        if (vibrationOn) vibrate()
        commitTyped(emoji)
        prefs.recentEmojis = listOf(emoji) + prefs.recentEmojis.filter { it != emoji }
    }

    override fun onEmojiBackspace() {
        if (vibrationOn) vibrate()
        handleBackspace()
    }

    override fun onEmojiPanelClosed() = hideEmoji()

    override fun recentEmojis(): List<String> = prefs.recentEmojis

    // ================================================================ toolbar

    override fun onSettingsClicked() = openSettings(scrollTo = null)

    private fun openSettings(scrollTo: String?) {
        val intent = Intent(this, SettingsActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (scrollTo != null) intent.putExtra(SettingsActivity.EXTRA_SCROLL_TO, scrollTo)
        startActivity(intent)
    }

    private fun notice(msgRes: Int, iconRes: Int = 0, autoHideMs: Long = 3500L) {
        toolbar?.showStatus(getString(msgRes), iconRes = iconRes, autoHideMs = autoHideMs)
    }

    private fun showPrivateFieldNotice() = notice(R.string.private_field_blocked, R.drawable.ic_lock)

    // ================================================================ voice typing

    override fun onMicClicked() {
        if (voice.isListening) {
            voice.stop()
            return
        }
        if (privacy == PrivacyGuard.Level.PRIVATE) {
            showPrivateFieldNotice()
            return
        }
        if (!VoicePermission.isGranted(this)) {
            startActivity(MicPermissionActivity.createIntent(this, startListeningAfter = true))
            return
        }
        startVoice()
    }

    private fun startVoice() {
        if (!voice.isAvailable()) {
            notice(R.string.voice_unavailable, R.drawable.ic_mic, 5000L)
            return
        }
        val ic = currentInputConnection ?: return
        hideEmoji()
        val tag = prefs.voiceLanguage.takeUnless { it == Prefs.VOICE_AUTO } ?: language.speechTag
        ic.finishComposingText()
        val before = ic.getTextBeforeCursor(1, 0)
        voicePrefix = if (!before.isNullOrEmpty() && !before[0].isWhitespace()) " " else ""
        voiceCapitalize = tag.startsWith("en") && prefs.autoCapitalize && run {
            val type = currentInputEditorInfo?.inputType ?: 0
            type and InputType.TYPE_MASK_CLASS == InputType.TYPE_CLASS_TEXT &&
                ic.getCursorCapsMode(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0
        }
        voiceComposing = false
        toolbar?.setListening(true)
        toolbar?.showStatus(
            getString(R.string.voice_starting, voiceLanguageName(tag)),
            tag = KeyboardToolbar.TAG_VOICE,
            iconRes = R.drawable.ic_mic,
            actionLabel = getString(R.string.action_done),
            onAction = { voice.stop() },
            onClose = { cancelVoice() },
        )
        voice.start(tag)
    }

    private fun voiceLanguageName(tag: String): String = when {
        tag.startsWith("bn") -> KeyboardLanguage.BANGLA.displayName
        tag.startsWith("ar") -> KeyboardLanguage.ARABIC.displayName
        else -> KeyboardLanguage.ENGLISH.displayName
    }

    private fun cancelVoice() {
        if (voice.isListening) voice.cancel()
        val ic = currentInputConnection
        if (voiceComposing && ic != null) {
            ic.setComposingText("", 1)
            ic.finishComposingText()
        }
        voiceComposing = false
        toolbar?.setListening(false)
    }

    /** If the user starts typing while dictating, keep what was heard and stop listening. */
    private fun stopVoiceForTyping() {
        if (voice.isListening) voice.cancel()
        finishVoiceComposing()
    }

    private fun finishVoiceComposing() {
        if (voiceComposing) {
            currentInputConnection?.finishComposingText()
            voiceComposing = false
        }
    }

    override fun onVoiceReady() {
        if (toolbar?.statusTag == KeyboardToolbar.TAG_VOICE) {
            toolbar?.updateStatusText(getString(R.string.voice_listening))
        }
    }

    override fun onVoicePartial(text: String) {
        val ic = currentInputConnection ?: return
        ic.setComposingText(voicePrefix + capitalizeIfNeeded(text), 1)
        voiceComposing = true
    }

    override fun onVoiceFinal(text: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(voicePrefix + capitalizeIfNeeded(text), 1)
        voiceComposing = false
        updateAutoShift()
    }

    override fun onVoiceError(message: String) {
        finishVoiceComposing()
        toolbar?.showStatus(message, tag = KeyboardToolbar.TAG_INFO, iconRes = R.drawable.ic_mic, autoHideMs = 3500L)
    }

    override fun onVoiceEnded() {
        toolbar?.setListening(false)
        if (toolbar?.statusTag == KeyboardToolbar.TAG_VOICE) toolbar?.showActions()
    }

    private fun capitalizeIfNeeded(text: String): String =
        if (voiceCapitalize && text.isNotEmpty() && text[0].isLowerCase()) {
            text.substring(0, 1).uppercase(Locale.ROOT) + text.substring(1)
        } else text

    // ================================================================ AI Fix & translate

    override fun onAiFixClicked() {
        if (!prefs.aiEnabled) {
            notice(R.string.ai_disabled)
            return
        }
        if (privacy != PrivacyGuard.Level.NORMAL) {
            showPrivateFieldNotice()
            return
        }
        val target = captureTarget() ?: return
        if (PrivacyGuard.containsSensitiveData(target.text)) {
            notice(R.string.ai_blocked_sensitive, R.drawable.ic_lock, 5000L)
            return
        }
        if (!aiClient.isConfigured) {
            showNeedsApi()
            return
        }
        runReplacement(target, getString(R.string.ai_fixing), getString(R.string.ai_fixed)) {
            when (val r = aiClient.fix(target.text, language.code)) {
                is AiBackendClient.Result.Success -> Outcome.Success(r.text)
                is AiBackendClient.Result.Failure -> backendFailure(r)
            }
        }
    }

    override fun onTranslateClicked() {
        if (privacy != PrivacyGuard.Level.NORMAL) {
            showPrivateFieldNotice()
            return
        }
        hideEmoji()
        toolbar?.showTranslateDirections(TranslationDirection.fromName(prefs.lastTranslateDirection))
    }

    override fun onTranslateDirectionChosen(direction: TranslationDirection) {
        prefs.lastTranslateDirection = direction.name
        val target = captureTarget() ?: return
        if (translation.usesBackend) {
            if (PrivacyGuard.containsSensitiveData(target.text)) {
                notice(R.string.ai_blocked_sensitive, R.drawable.ic_lock, 5000L)
                return
            }
            if (!aiClient.isConfigured) {
                showNeedsApi()
                return
            }
        }
        val progress = object : TranslationService.Progress {
            override fun onDownloadingModel(language: KeyboardLanguage) {
                toolbar?.updateStatusText(getString(R.string.translate_downloading, language.displayName))
            }
        }
        runReplacement(
            target,
            getString(R.string.translating, direction.label),
            getString(R.string.translated, direction.to.displayName),
        ) {
            when (val r = translation.translate(target.text, direction, progress)) {
                is TranslationService.Result.Success -> Outcome.Success(r.text)
                is TranslationService.Result.Failure ->
                    if (r.backendFailure != null) backendFailure(r.backendFailure)
                    else Outcome.Failure(getString(R.string.translate_failed))
            }
        }
    }

    private fun captureTarget(): EditorText.Target? {
        val ic = currentInputConnection ?: return null
        stopVoiceForTyping()
        return when (val c = EditorText.capture(ic)) {
            is EditorText.Capture.Ok -> c.target
            EditorText.Capture.Empty -> {
                notice(R.string.ai_nothing_to_process)
                null
            }
            EditorText.Capture.TooLong -> {
                notice(R.string.ai_too_long)
                null
            }
        }
    }

    private sealed class Outcome {
        data class Success(val text: String) : Outcome()

        /** @param offerSetup show a "Set up" button that opens the backend settings */
        data class Failure(val message: String, val offerSetup: Boolean = false) : Outcome()
    }

    private fun backendFailure(f: AiBackendClient.Result.Failure): Outcome.Failure {
        val setupKinds = setOf(
            AiBackendClient.Kind.NOT_CONFIGURED, AiBackendClient.Kind.INVALID_URL, AiBackendClient.Kind.NETWORK,
            AiBackendClient.Kind.UNAUTHORIZED, AiBackendClient.Kind.BAD_RESPONSE,
        )
        return Outcome.Failure(AiMessages.forFailure(this, f), offerSetup = f.kind in setupKinds)
    }

    /** Runs [work] off the UI thread, then replaces [target] in the text field with the result. */
    private fun runReplacement(
        target: EditorText.Target,
        progressMessage: String,
        doneMessage: String,
        work: suspend () -> Outcome,
    ) {
        aiJob?.cancel()
        val session = inputSession
        toolbar?.showStatus(
            progressMessage,
            tag = KeyboardToolbar.TAG_AI,
            progress = true,
            onClose = { aiJob?.cancel() },
        )
        aiJob = scope.launch {
            val outcome = work()
            if (session != inputSession) return@launch // user moved to another text field
            when (outcome) {
                is Outcome.Failure -> toolbar?.showStatus(
                    outcome.message,
                    actionLabel = if (outcome.offerSetup) getString(R.string.action_setup) else null,
                    onAction = { openSettings(scrollTo = Prefs.KEY_BACKEND_URL) },
                    autoHideMs = 9000L,
                )
                is Outcome.Success -> {
                    val ic = currentInputConnection ?: return@launch
                    val result = outcome.text.trim().let { if (target.text.endsWith(" ")) "$it " else it }
                    if (result == target.text) {
                        notice(R.string.ai_no_changes, R.drawable.ic_check, 2500L)
                        return@launch
                    }
                    try {
                        val undo = EditorText.replace(ic, target, result)
                        lastUndo = undo
                        toolbar?.showStatus(
                            doneMessage,
                            iconRes = R.drawable.ic_check,
                            actionLabel = if (undo != null) getString(R.string.action_undo) else null,
                            onAction = { performUndo() },
                            autoHideMs = 6000L,
                        )
                    } catch (e: EditorText.StaleTextException) {
                        notice(R.string.ai_text_changed)
                    }
                    updateAutoShift()
                }
            }
        }
    }

    private fun performUndo() {
        val undo = lastUndo ?: return
        val ic = currentInputConnection ?: return
        lastUndo = null
        if (EditorText.undo(ic, undo)) notice(R.string.undo_done, R.drawable.ic_undo, 2000L)
        else notice(R.string.undo_failed)
    }

    /** Shown when no Backend API URL is saved yet — no network request is made. */
    private fun showNeedsApi() {
        toolbar?.showStatus(
            getString(R.string.ai_needs_api),
            iconRes = R.drawable.ic_ai_fix,
            actionLabel = getString(R.string.action_setup),
            onAction = { openSettings(scrollTo = Prefs.KEY_BACKEND_URL) },
            autoHideMs = 9000L,
        )
    }

    private companion object {
        const val DOUBLE_TAP_MS = 350L
        val NO_CAPS_VARIATIONS = setOf(
            InputType.TYPE_TEXT_VARIATION_URI,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_FILTER,
        )
    }
}
