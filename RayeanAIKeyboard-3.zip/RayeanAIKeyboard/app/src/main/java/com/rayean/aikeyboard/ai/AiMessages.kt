package com.rayean.aikeyboard.ai

import android.content.Context
import com.rayean.aikeyboard.R

/** Turns backend failures into clear, user-facing messages. */
object AiMessages {

    fun forFailure(context: Context, failure: AiBackendClient.Result.Failure): String = when (failure.kind) {
        AiBackendClient.Kind.NOT_CONFIGURED -> context.getString(R.string.ai_needs_api)
        AiBackendClient.Kind.INVALID_URL -> context.getString(R.string.ai_error_invalid_url, failure.detail.orEmpty())
        AiBackendClient.Kind.NETWORK -> context.getString(
            R.string.ai_error_network,
            failure.host,
            context.getString(networkReason(failure.detail)),
        )
        AiBackendClient.Kind.UNAUTHORIZED -> context.getString(R.string.ai_error_unauthorized)
        AiBackendClient.Kind.RATE_LIMITED -> context.getString(R.string.ai_error_rate_limited)
        AiBackendClient.Kind.TOO_LONG -> context.getString(R.string.ai_too_long)
        AiBackendClient.Kind.SERVER -> context.getString(R.string.ai_error_server, failure.detail.orEmpty())
        AiBackendClient.Kind.BAD_RESPONSE -> context.getString(R.string.ai_error_bad_response, failure.host)
    }

    private fun networkReason(detail: String?): Int = when (detail) {
        AiBackendClient.NetworkProblem.NO_HOST.name -> R.string.net_no_host
        AiBackendClient.NetworkProblem.REFUSED.name -> R.string.net_refused
        AiBackendClient.NetworkProblem.TIMEOUT.name -> R.string.net_timeout
        AiBackendClient.NetworkProblem.TLS.name -> R.string.net_tls
        else -> R.string.net_other
    }
}
