package com.rayean.aikeyboard.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.rayean.aikeyboard.R

/**
 * Draws a [KeyboardLayout] and turns touches into key events.
 * This is the key area of the real system keyboard (hosted by RayeanImeService),
 * not an in-app simulation.
 */
class KeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    interface Listener {
        /** Finger went down on a key: play sound / vibration. */
        fun onKeyDown(key: Key)
        /** A key was activated (tap, or press for Shift/Backspace). */
        fun onKey(key: Key)
        /** Auto-repeat while Backspace is held. */
        fun onKeyRepeat(key: Key)
        /** Long-press. Return true if handled — the normal tap is then skipped. */
        fun onKeyLongPress(key: Key): Boolean
    }

    var listener: Listener? = null

    var keyboardLayout: KeyboardLayout? = null
        set(value) {
            if (field == value) return
            field = value
            cancelTouches()
            requestLayout()
            computeKeyAreas()
            invalidate()
        }

    var theme: KeyboardTheme = KeyboardTheme.LIGHT
        set(value) { field = value; invalidate() }

    var shiftState: ShiftState = ShiftState.OFF
        set(value) { if (field != value) { field = value; invalidate() } }

    var enterStyle: EnterStyle = EnterStyle.RETURN
        set(value) { if (field != value) { field = value; invalidate() } }

    /** Shown faintly on the space bar (current language name). */
    var spaceLabel: String = ""
        set(value) { if (field != value) { field = value; invalidate() } }

    /** Shown on the language-switch key: EN / বাং / عربي. */
    var languageKeyLabel: String = "EN"
        set(value) { if (field != value) { field = value; invalidate() } }

    var heightScale: Float = 1f
        set(value) { if (field != value) { field = value; requestLayout() } }

    // ---- dimensions ----
    private val density = resources.displayMetrics.density
    private val rowHeight: Float get() = 54f * density * heightScale
    private val keyGapH = 5f * density
    private val keyGapV = 8f * density
    private val sidePadding = 3f * density
    private val topPadding = 4f * density
    private val bottomPadding = 4f * density
    private val corner = 7f * density

    private class KeyArea(val key: Key, val draw: RectF, val hit: RectF)
    private val areas = ArrayList<KeyArea>()

    // ---- paints ----
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
    private val shadowRect = RectF()
    private val inkBounds = Rect()

    /** Bundled Noto Sans Bengali, so Bangla keys look the same and correct on every phone. */
    private val bengaliTypeface: Typeface by lazy {
        runCatching { resources.getFont(R.font.noto_sans_bengali) }.getOrNull() ?: Typeface.DEFAULT
    }

    private fun typefaceFor(text: String): Typeface =
        if (KeyLabels.containsBengali(text)) bengaliTypeface else Typeface.DEFAULT
    private val iconCache = HashMap<Int, Drawable>()

    // ---- touch state ----
    private class Pointer(val id: Int, var area: KeyArea) {
        var longPressed = false
        var pending: Runnable? = null
    }
    private val pointers = LinkedHashMap<Int, Pointer>()
    private val handler = Handler(Looper.getMainLooper())

    init {
        isHapticFeedbackEnabled = false
        isSoundEffectsEnabled = false
        contentDescription = context.getString(R.string.ime_name)
    }

    // ------------------------------------------------------------------ layout

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val rows = keyboardLayout?.rows?.size ?: 4
        val height = (topPadding + rows * rowHeight + bottomPadding).toInt()
        setMeasuredDimension(width, height)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        computeKeyAreas()
    }

    private fun computeKeyAreas() {
        areas.clear()
        val layout = keyboardLayout ?: return
        if (width == 0) return
        val usable = width - 2 * sidePadding
        val unit = usable / layout.maxRowUnits
        var y = topPadding
        val lastRow = layout.rows.lastIndex
        layout.rows.forEachIndexed { rowIndex, row ->
            val rowUnits = row.sumOf { it.width.toDouble() }.toFloat()
            var x = sidePadding + (usable - rowUnits * unit) / 2f
            row.forEachIndexed { i, key ->
                val w = key.width * unit
                val draw = RectF(x + keyGapH / 2, y + keyGapV / 2, x + w - keyGapH / 2, y + rowHeight - keyGapV / 2)
                // Hit areas have no gaps and stretch to the edges, so there are no dead zones.
                val hit = RectF(
                    if (i == 0) 0f else x,
                    if (rowIndex == 0) 0f else y,
                    if (i == row.lastIndex) width.toFloat() else x + w,
                    if (rowIndex == lastRow) height.toFloat().coerceAtLeast(y + rowHeight) else y + rowHeight,
                )
                areas += KeyArea(key, draw, hit)
                x += w
            }
            y += rowHeight
        }
    }

    // ------------------------------------------------------------------ drawing

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(theme.background)
        if (areas.isEmpty() && keyboardLayout != null) computeKeyAreas()
        val pressed = pointers.values.map { it.area }
        for (area in areas) drawKey(canvas, area, area in pressed)
    }

    private fun drawKey(canvas: Canvas, area: KeyArea, pressed: Boolean) {
        val key = area.key
        val r = area.draw
        val shifted = shiftState != ShiftState.OFF

        val bg = when {
            key.type == KeyType.ENTER ->
                if (pressed) ColorUtils.blendARGB(theme.accent, theme.keyText, 0.2f) else theme.accent
            key.type == KeyType.SHIFT && shiftState == ShiftState.LOCKED ->
                ColorUtils.blendARGB(theme.functionKey, theme.accent, 0.35f)
            key.isFunctional -> if (pressed) theme.functionKeyPressed else theme.functionKey
            else -> if (pressed) theme.keyPressed else theme.key
        }

        if (Color.alpha(theme.keyShadow) > 0) {
            shadowRect.set(r.left, r.top + density, r.right, r.bottom + density)
            keyPaint.color = theme.keyShadow
            canvas.drawRoundRect(shadowRect, corner, corner, keyPaint)
        }
        keyPaint.color = bg
        canvas.drawRoundRect(r, corner, corner, keyPaint)

        val fg = if (key.type == KeyType.ENTER) theme.onAccent else theme.keyText
        when (key.type) {
            KeyType.SHIFT -> {
                val icon = when (shiftState) {
                    ShiftState.OFF -> R.drawable.ic_shift
                    ShiftState.ON -> R.drawable.ic_shift_on
                    ShiftState.LOCKED -> R.drawable.ic_caps_lock
                }
                drawIcon(canvas, icon, r, if (shiftState == ShiftState.OFF) fg else theme.accent)
            }
            KeyType.BACKSPACE -> drawIcon(canvas, R.drawable.ic_backspace, r, fg)
            KeyType.EMOJI -> drawIcon(canvas, R.drawable.ic_emoji, r, fg)
            KeyType.ENTER -> {
                val icon = when (enterStyle) {
                    EnterStyle.RETURN -> R.drawable.ic_return
                    EnterStyle.SEARCH -> R.drawable.ic_search
                    EnterStyle.SEND -> R.drawable.ic_send
                    EnterStyle.GO, EnterStyle.NEXT -> R.drawable.ic_arrow_forward
                    EnterStyle.DONE -> R.drawable.ic_check
                    EnterStyle.PREVIOUS -> R.drawable.ic_return
                }
                drawIcon(canvas, icon, r, fg)
            }
            KeyType.LANGUAGE -> drawText(canvas, languageKeyLabel, r, fg, rowHeight * 0.26f)
            KeyType.SPACE -> {
                val label = if (key.label.isNotBlank()) key.label else spaceLabel
                drawText(canvas, label, r, theme.hintText, rowHeight * 0.24f)
            }
            KeyType.MODE_SYMBOLS, KeyType.MODE_SYMBOLS_2, KeyType.MODE_ALPHA ->
                drawText(canvas, key.label, r, fg, rowHeight * 0.26f)
            KeyType.CHAR -> {
                val label = key.labelFor(shifted)
                val big = label.codePointCount(0, label.length) <= 2
                drawText(canvas, label, r, fg, rowHeight * if (big) 0.40f else 0.27f)
                (key.longPressLabel ?: key.longPress)?.let { hint ->
                    val shown = KeyLabels.display(hint)
                    hintPaint.color = theme.hintText
                    hintPaint.typeface = typefaceFor(shown)
                    hintPaint.textSize = rowHeight * 0.20f
                    val maxHint = r.width() * 0.5f
                    val w = hintPaint.measureText(shown)
                    if (w > maxHint && w > 0f) hintPaint.textSize *= maxHint / w
                    canvas.drawText(shown, r.right - 4f * density, r.top + rowHeight * 0.20f + 1f * density, hintPaint)
                }
            }
        }
    }

    private fun drawText(canvas: Canvas, text: String, r: RectF, color: Int, size: Float) {
        if (text.isEmpty()) return
        val shown = KeyLabels.display(text)
        val bengali = KeyLabels.containsBengali(shown)
        textPaint.color = color
        textPaint.typeface = if (bengali) bengaliTypeface else Typeface.DEFAULT
        val isMark = shown.startsWith(KeyLabels.NBSP)
        // Lone vowel signs (ু ূ ্ …) are small glyphs; draw them a little larger so they read clearly.
        textPaint.textSize = size * (if (bengali) 0.92f else 1f) * (if (isMark) 1.15f else 1f)
        val maxWidth = r.width() * 0.86f
        val measured = textPaint.measureText(shown)
        if (measured > maxWidth && measured > 0f) textPaint.textSize = textPaint.textSize * maxWidth / measured

        if (isMark) {
            // A lone vowel sign / mark: centre its actual ink, since it has no visible base.
            textPaint.textAlign = Paint.Align.LEFT
            textPaint.getTextBounds(shown, 0, shown.length, inkBounds)
            canvas.drawText(shown, r.centerX() - inkBounds.exactCenterX(), r.centerY() - inkBounds.exactCenterY(), textPaint)
            textPaint.textAlign = Paint.Align.CENTER
            return
        }
        val baseline = if (bengali) {
            // Use a typical consonant as reference so all Bangla letters share one, centred baseline.
            textPaint.getTextBounds(REFERENCE_BENGALI, 0, REFERENCE_BENGALI.length, inkBounds)
            r.centerY() - inkBounds.exactCenterY()
        } else {
            r.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f
        }
        canvas.drawText(shown, r.centerX(), baseline, textPaint)
    }

    private fun drawIcon(canvas: Canvas, resId: Int, r: RectF, tint: Int) {
        val d = iconCache.getOrPut(resId) {
            ContextCompat.getDrawable(context, resId)!!.mutate()
        }
        d.setTint(tint)
        val size = (minOf(r.width(), r.height()) * 0.52f).toInt()
        val left = (r.centerX() - size / 2f).toInt()
        val top = (r.centerY() - size / 2f).toInt()
        d.setBounds(left, top, left + size, top + size)
        d.draw(canvas)
    }

    // ------------------------------------------------------------------ touch

    private fun findArea(x: Float, y: Float): KeyArea? = areas.firstOrNull { it.hit.contains(x, y) }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = event.actionIndex
                val area = findArea(event.getX(idx), event.getY(idx)) ?: return true
                if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN) {
                    // Fast two-thumb typing: a new finger commits any letter still held down.
                    for (p in pointers.values.toList()) {
                        if (!p.longPressed && !firesOnDown(p.area.key)) {
                            pointers.remove(p.id)
                            finish(p, fire = true)
                        }
                    }
                }
                press(event.getPointerId(idx), area)
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val p = pointers[event.getPointerId(i)] ?: continue
                    if (p.longPressed || firesOnDown(p.area.key)) continue
                    val next = findArea(event.getX(i), event.getY(i)) ?: continue
                    if (next !== p.area) {
                        // Sliding to a neighbouring key corrects the press (like most keyboards).
                        p.pending?.let { handler.removeCallbacks(it) }
                        p.area = next
                        scheduleLongPress(p)
                        invalidate()
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val p = pointers.remove(event.getPointerId(event.actionIndex))
                if (p != null) finish(p, fire = !p.longPressed && !firesOnDown(p.area.key))
            }
            MotionEvent.ACTION_CANCEL -> cancelTouches()
        }
        return true
    }

    private fun firesOnDown(key: Key) = key.type == KeyType.BACKSPACE || key.type == KeyType.SHIFT

    private fun press(id: Int, area: KeyArea) {
        val p = Pointer(id, area)
        pointers[id] = p
        val key = area.key
        listener?.onKeyDown(key)
        when {
            key.repeats -> {
                listener?.onKey(key)
                val repeat = object : Runnable {
                    override fun run() {
                        if (pointers[id] !== p) return
                        listener?.onKeyRepeat(key)
                        handler.postDelayed(this, REPEAT_INTERVAL_MS)
                    }
                }
                p.pending = repeat
                handler.postDelayed(repeat, REPEAT_START_MS)
            }
            key.type == KeyType.SHIFT -> listener?.onKey(key)
            else -> scheduleLongPress(p)
        }
        invalidate()
    }

    private fun scheduleLongPress(p: Pointer) {
        val r = Runnable {
            if (pointers[p.id] === p && listener?.onKeyLongPress(p.area.key) == true) {
                p.longPressed = true
                invalidate()
            }
        }
        p.pending = r
        handler.postDelayed(r, LONG_PRESS_MS)
    }

    private fun finish(p: Pointer, fire: Boolean) {
        p.pending?.let { handler.removeCallbacks(it) }
        p.pending = null
        if (fire) listener?.onKey(p.area.key)
        invalidate()
    }

    fun cancelTouches() {
        for (p in pointers.values) p.pending?.let { handler.removeCallbacks(it) }
        pointers.clear()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        cancelTouches()
        super.onDetachedFromWindow()
    }

    private companion object {
        const val REFERENCE_BENGALI = "ক"
        const val LONG_PRESS_MS = 380L
        const val REPEAT_START_MS = 400L
        const val REPEAT_INTERVAL_MS = 50L
    }
}
