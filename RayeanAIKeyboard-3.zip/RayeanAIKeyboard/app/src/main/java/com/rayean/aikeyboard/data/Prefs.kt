package com.rayean.aikeyboard.data

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import com.rayean.aikeyboard.BuildConfig

/**
 * Typed access to the user's settings. Keys must match res/xml/preferences.xml.
 * Nothing the user types is ever stored here — only settings and recent emoji.
 */
class Prefs(context: Context) {

    val raw: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context.applicationContext)

    // ---- Keyboard ----
    val enabledLanguages: List<KeyboardLanguage>
        get() {
            val codes = raw.getStringSet(KEY_LANGUAGES, null) ?: DEFAULT_LANGUAGES
            val list = KeyboardLanguage.entries.filter { it.code in codes }
            return list.ifEmpty { listOf(KeyboardLanguage.ENGLISH) }
        }

    var currentLanguage: KeyboardLanguage
        get() {
            val enabled = enabledLanguages
            val saved = KeyboardLanguage.fromCode(raw.getString(KEY_CURRENT_LANGUAGE, null))
            return if (saved != null && saved in enabled) saved else enabled.first()
        }
        set(value) = raw.edit { putString(KEY_CURRENT_LANGUAGE, value.code) }

    val showNumberRow: Boolean get() = raw.getBoolean(KEY_NUMBER_ROW, true)
    val autoCapitalize: Boolean get() = raw.getBoolean(KEY_AUTO_CAP, true)
    val themeId: String get() = raw.getString(KEY_THEME, "system") ?: "system"
    val heightScale: Float
        get() = raw.getString(KEY_HEIGHT, "1.0")?.toFloatOrNull()?.coerceIn(0.7f, 1.4f) ?: 1.0f

    // ---- Feedback ----
    val vibrationEnabled: Boolean get() = raw.getBoolean(KEY_VIBRATION, true)
    val soundEnabled: Boolean get() = raw.getBoolean(KEY_SOUND, false)

    // ---- Voice ----
    /** "auto" = follow the current keyboard language, otherwise a BCP-47 tag such as "bn-BD". */
    val voiceLanguage: String get() = raw.getString(KEY_VOICE_LANGUAGE, VOICE_AUTO) ?: VOICE_AUTO

    // ---- AI ----
    val aiEnabled: Boolean get() = raw.getBoolean(KEY_AI_ENABLED, true)
    val translationEngine: String get() = raw.getString(KEY_TRANSLATION_ENGINE, ENGINE_ON_DEVICE) ?: ENGINE_ON_DEVICE

    /** Base URL of the Rayean AI backend. The Settings value wins over the build default. */
    val aiBackendUrl: String
        get() {
            val saved = raw.getString(KEY_BACKEND_URL, null)?.trim().orEmpty()
            return BackendUrl.normalize(saved.ifEmpty { BuildConfig.AI_BACKEND_URL })
        }

    val aiBackendToken: String get() = raw.getString(KEY_BACKEND_TOKEN, "")?.trim().orEmpty()

    var lastTranslateDirection: String
        get() = raw.getString(KEY_LAST_DIRECTION, "BN_EN") ?: "BN_EN"
        set(value) = raw.edit { putString(KEY_LAST_DIRECTION, value) }

    // ---- Emoji ----
    var recentEmojis: List<String>
        get() = raw.getString(KEY_RECENT_EMOJI, "")?.split('\u0001')?.filter { it.isNotEmpty() } ?: emptyList()
        set(value) = raw.edit { putString(KEY_RECENT_EMOJI, value.take(32).joinToString("\u0001")) }

    companion object {
        const val KEY_LANGUAGES = "keyboard_languages"
        const val KEY_CURRENT_LANGUAGE = "current_language"
        const val KEY_NUMBER_ROW = "number_row"
        const val KEY_AUTO_CAP = "auto_cap"
        const val KEY_THEME = "theme"
        const val KEY_HEIGHT = "keyboard_height"
        const val KEY_VIBRATION = "vibration"
        const val KEY_SOUND = "sound"
        const val KEY_VOICE_LANGUAGE = "voice_language"
        const val KEY_MIC_PERMISSION = "mic_permission"
        const val KEY_AI_ENABLED = "ai_enabled"
        const val KEY_TRANSLATION_ENGINE = "translation_engine"
        const val KEY_BACKEND_URL = "ai_backend_url"
        const val KEY_BACKEND_TOKEN = "ai_backend_token"
        const val KEY_BACKEND_TEST = "ai_backend_test"
        const val KEY_SETUP = "open_setup"
        const val KEY_VERSION = "version"
        const val KEY_LAST_DIRECTION = "last_translate_direction"
        const val KEY_RECENT_EMOJI = "recent_emojis"

        const val VOICE_AUTO = "auto"
        const val ENGINE_ON_DEVICE = "on_device"
        const val ENGINE_AI_BACKEND = "ai_backend"

        val DEFAULT_LANGUAGES = setOf("en", "bn", "ar")
    }
}
