package com.rayean.aikeyboard.translate

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.rayean.aikeyboard.ai.AiBackendClient
import com.rayean.aikeyboard.data.KeyboardLanguage
import com.rayean.aikeyboard.data.Prefs
import kotlinx.coroutines.tasks.await

/**
 * Translation with two real engines:
 *  - ON-DEVICE (default): Google ML Kit Translation. Works without any server; each language
 *    pack (~30 MB) is downloaded once, then translation runs fully offline on the phone.
 *  - AI BACKEND: your Rayean AI backend (see /backend), for context-aware results.
 */
class TranslationService(private val prefs: Prefs, private val backend: AiBackendClient) {

    sealed class Result {
        data class Success(val text: String) : Result()
        data class Failure(val message: String?, val backendFailure: AiBackendClient.Result.Failure? = null) : Result()
    }

    interface Progress {
        fun onDownloadingModel(language: KeyboardLanguage)
    }

    private val translators = HashMap<TranslationDirection, Translator>()

    val usesBackend: Boolean get() = prefs.translationEngine == Prefs.ENGINE_AI_BACKEND

    suspend fun translate(text: String, direction: TranslationDirection, progress: Progress): Result =
        if (usesBackend) {
            when (val r = backend.translate(text, direction.from.code, direction.to.code)) {
                is AiBackendClient.Result.Success -> Result.Success(r.text)
                is AiBackendClient.Result.Failure -> Result.Failure(r.detail, r)
            }
        } else {
            translateOnDevice(text, direction, progress)
        }

    private suspend fun translateOnDevice(text: String, direction: TranslationDirection, progress: Progress): Result {
        return try {
            val modelManager = RemoteModelManager.getInstance()
            for (lang in listOf(direction.from, direction.to)) {
                if (lang == KeyboardLanguage.ENGLISH) continue // English model is built in
                val model = TranslateRemoteModel.Builder(lang.mlKitCode).build()
                if (!modelManager.isModelDownloaded(model).await()) {
                    progress.onDownloadingModel(lang)
                }
            }
            val translator = translators.getOrPut(direction) {
                Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(direction.from.mlKitCode)
                        .setTargetLanguage(direction.to.mlKitCode)
                        .build()
                )
            }
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            val out = translator.translate(text).await()
            if (out.isNullOrBlank()) Result.Failure(null) else Result.Success(out)
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            Result.Failure(e.message)
        }
    }

    fun close() {
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
    }
}
