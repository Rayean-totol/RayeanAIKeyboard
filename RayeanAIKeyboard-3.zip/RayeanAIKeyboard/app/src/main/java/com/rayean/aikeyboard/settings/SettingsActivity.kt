package com.rayean.aikeyboard.settings

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.preference.EditTextPreference
import androidx.preference.ListPreference
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.rayean.aikeyboard.BuildConfig
import com.rayean.aikeyboard.R
import com.rayean.aikeyboard.ai.AiBackendClient
import com.rayean.aikeyboard.ai.AiMessages
import com.rayean.aikeyboard.data.BackendUrl
import com.rayean.aikeyboard.data.Prefs
import com.rayean.aikeyboard.setup.SetupActivity
import com.rayean.aikeyboard.voice.VoicePermission
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            val fragment = SettingsFragment()
            fragment.arguments = Bundle().apply {
                putString(EXTRA_SCROLL_TO, intent.getStringExtra(EXTRA_SCROLL_TO))
            }
            supportFragmentManager.beginTransaction()
                .replace(android.R.id.content, fragment)
                .commit()
        }
    }

    companion object {
        /** Preference key to scroll to when the screen opens (e.g. the Backend API URL). */
        const val EXTRA_SCROLL_TO = "scroll_to"
    }
}

class SettingsFragment : PreferenceFragmentCompat() {

    private lateinit var prefs: Prefs

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            // "Don't ask again" — send the user to the app's system settings page.
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", requireContext().packageName, null))
            )
        }
        updateMicSummary()
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)
        prefs = Prefs(requireContext())

        findPreference<Preference>(Prefs.KEY_SETUP)?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), SetupActivity::class.java))
            true
        }

        findPreference<MultiSelectListPreference>(Prefs.KEY_LANGUAGES)?.setOnPreferenceChangeListener { _, newValue ->
            val set = (newValue as? Set<*>).orEmpty()
            if (set.isEmpty()) {
                Toast.makeText(requireContext(), R.string.pref_languages_empty, Toast.LENGTH_SHORT).show()
                false
            } else true
        }

        findPreference<ListPreference>(Prefs.KEY_CURRENT_LANGUAGE)?.setOnPreferenceChangeListener { _, newValue ->
            // Choosing a keyboard language also enables it for the language switch key.
            val code = newValue as String
            val langPref = findPreference<MultiSelectListPreference>(Prefs.KEY_LANGUAGES)
            if (langPref != null && code !in langPref.values) {
                langPref.values = langPref.values + code
            }
            true
        }

        findPreference<Preference>(Prefs.KEY_MIC_PERMISSION)?.setOnPreferenceClickListener {
            if (!VoicePermission.isGranted(requireContext())) {
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
            true
        }

        findPreference<EditTextPreference>(Prefs.KEY_BACKEND_URL)?.apply {
            setOnBindEditTextListener { edit ->
                edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
                edit.hint = getString(R.string.pref_backend_url_hint)
            }
            setOnPreferenceChangeListener { pref, newValue ->
                val raw = (newValue as String).trim()
                if (raw.isEmpty()) return@setOnPreferenceChangeListener true
                if (!BackendUrl.isValid(raw)) {
                    Toast.makeText(requireContext(), R.string.pref_backend_url_invalid, Toast.LENGTH_LONG).show()
                    return@setOnPreferenceChangeListener false
                }
                // Save the cleaned-up form (adds https://, removes /health etc.).
                (pref as EditTextPreference).text = BackendUrl.normalize(raw)
                false
            }
            summaryProvider = Preference.SummaryProvider<EditTextPreference> { pref ->
                val value = pref.text?.trim().orEmpty()
                when {
                    value.isNotEmpty() -> value
                    BuildConfig.AI_BACKEND_URL.isNotEmpty() -> getString(R.string.pref_backend_url_build_default, BuildConfig.AI_BACKEND_URL)
                    else -> getString(R.string.pref_backend_url_not_set)
                }
            }
        }

        findPreference<EditTextPreference>(Prefs.KEY_BACKEND_TOKEN)?.apply {
            setOnBindEditTextListener { edit ->
                edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            summaryProvider = Preference.SummaryProvider<EditTextPreference> { pref ->
                getString(if (pref.text.isNullOrBlank()) R.string.pref_backend_token_not_set else R.string.pref_backend_token_set)
            }
        }

        findPreference<Preference>(Prefs.KEY_BACKEND_TEST)?.setOnPreferenceClickListener { pref ->
            testBackend(pref)
            true
        }

        findPreference<Preference>(Prefs.KEY_VERSION)?.summary =
            getString(R.string.pref_version_summary, BuildConfig.VERSION_NAME)

        arguments?.getString(SettingsActivity.EXTRA_SCROLL_TO)?.let { scrollToPreference(it) }
    }

    override fun onResume() {
        super.onResume()
        updateMicSummary()
    }

    private fun updateMicSummary() {
        val pref = findPreference<Preference>(Prefs.KEY_MIC_PERMISSION) ?: return
        pref.summary = getString(
            if (VoicePermission.isGranted(requireContext())) R.string.pref_mic_granted else R.string.pref_mic_not_granted
        )
    }

    /** Real end-to-end check: /health, then an actual AI Fix of a sample sentence. */
    private fun testBackend(pref: Preference) {
        pref.summary = getString(R.string.pref_backend_testing)
        val client = AiBackendClient(prefs)
        viewLifecycleOwner.lifecycleScope.launch {
            val health = client.health()
            if (health is AiBackendClient.Result.Failure) {
                pref.summary = AiMessages.forFailure(requireContext(), health)
                return@launch
            }
            pref.summary = getString(R.string.pref_backend_testing_fix)
            pref.summary = when (val fix = client.fix(TEST_SENTENCE, "en")) {
                is AiBackendClient.Result.Success -> getString(R.string.pref_backend_test_ok, TEST_SENTENCE, fix.text)
                is AiBackendClient.Result.Failure -> AiMessages.forFailure(requireContext(), fix)
            }
        }
    }

    private companion object {
        const val TEST_SENTENCE = "I am go market"
    }
}
