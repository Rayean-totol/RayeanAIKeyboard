package com.rayean.aikeyboard.ime

import java.text.BreakIterator

/**
 * How many UTF-16 units one Backspace press removes from the text before the cursor.
 *
 *  - Emoji (including ZWJ sequences, flags and skin tones) and other clusters: the whole cluster.
 *  - Bengali and Arabic: one code point, so a vowel sign (া ি …), hasanta (্) or harakah can be
 *    removed on its own — except a nukta letter (য় ড় ঢ় = letter + ়), which goes in one press.
 */
object TextDeletion {

    private const val BENGALI_NUKTA = 0x09BC

    fun lengthToDelete(before: CharSequence): Int {
        val text = before.toString()
        val end = text.length
        if (end == 0) return 0
        val last = text.codePointBefore(end)
        val lastLen = Character.charCount(last)

        val bi = BreakIterator.getCharacterInstance()
        bi.setText(text)
        val clusterStart = bi.preceding(end).let { if (it == BreakIterator.DONE || it >= end) end - lastLen else it }
        val first = text.codePointAt(clusterStart)

        // Emoji, Latin letters with accents, etc.: delete the whole cluster.
        if (!isComplexScript(first) && !isComplexScript(last)) return end - clusterStart

        if (last == BENGALI_NUKTA && end - lastLen > 0) {
            val base = text.codePointBefore(end - lastLen)
            if (base in 0x0995..0x09B9) return lastLen + Character.charCount(base)
        }
        return lastLen
    }

    private fun isComplexScript(cp: Int): Boolean =
        cp in 0x0980..0x09FF ||            // Bengali
            cp in 0x0600..0x06FF ||        // Arabic
            cp in 0x0750..0x077F ||
            cp in 0x08A0..0x08FF ||
            cp in 0xFB50..0xFDFF ||
            cp in 0xFE70..0xFEFF
}
