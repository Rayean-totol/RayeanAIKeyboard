package com.rayean.aikeyboard.ai

import com.rayean.aikeyboard.BuildConfig
import com.rayean.aikeyboard.data.BackendUrl
import com.rayean.aikeyboard.data.Prefs
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Client for the Rayean AI backend (see /backend). The app never talks to an AI provider
 * directly, so no provider API key ships inside the APK — the backend holds it.
 *
 *   POST {baseUrl}/v1/fix        {"text": "...", "keyboard_language": "en|bn|ar"}  -> {"text": "..."}
 *   POST {baseUrl}/v1/translate  {"text": "...", "source": "bn", "target": "en"}   -> {"text": "..."}
 *   GET  {baseUrl}/health                                                         -> {"ok": true, "configured": true}
 *
 * Header: Authorization: Bearer <app token>  (Settings → App token, must match APP_TOKEN on the backend)
 */
class AiBackendClient(private val prefs: Prefs) {

    sealed class Result {
        data class Success(val text: String) : Result()

        /**
         * @param detail server error message, or the network problem
         * @param host   backend host the request went to (for messages)
         */
        data class Failure(val kind: Kind, val detail: String? = null, val host: String = "") : Result()
    }

    enum class Kind {
        /** No backend URL saved in Settings. */
        NOT_CONFIGURED,
        /** URL saved but it is not a valid web address. */
        INVALID_URL,
        /** Could not connect: no internet, wrong address, timeout, TLS problem. */
        NETWORK,
        /** Backend rejected the app token (401/403). */
        UNAUTHORIZED,
        RATE_LIMITED,
        TOO_LONG,
        /** Backend answered with an error message (e.g. no AI key set, provider error). */
        SERVER,
        /** Something answered, but not like the Rayean backend. */
        BAD_RESPONSE,
    }

    enum class NetworkProblem { NO_HOST, REFUSED, TIMEOUT, TLS, OTHER }

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    val isConfigured: Boolean get() = prefs.aiBackendUrl.isNotEmpty()

    suspend fun fix(text: String, keyboardLanguage: String): Result =
        post("/v1/fix", JSONObject().put("text", text).put("keyboard_language", keyboardLanguage))

    suspend fun translate(text: String, source: String, target: String): Result =
        post("/v1/translate", JSONObject().put("text", text).put("source", source).put("target", target))

    /** Success text is "provider · model" when the backend has an AI key configured. */
    suspend fun health(): Result {
        val base = checkedBase() ?: return notConfiguredOrInvalid()
        val request = baseRequest("$base/health").get().build()
        return execute(request, base) { body ->
            if (!body.optBoolean("ok")) null
            else if (!body.optBoolean("configured")) "!no-key"
            else listOf(body.optString("provider"), body.optString("model")).filter { it.isNotEmpty() }.joinToString(" · ")
                .ifEmpty { "ok" }
        }.let { r ->
            if (r is Result.Success && r.text == "!no-key") {
                Result.Failure(Kind.SERVER, "Backend is running but has no AI key. Add the ANTHROPIC_API_KEY secret.", BackendUrl.host(base))
            } else r
        }
    }

    private fun checkedBase(): String? {
        val base = prefs.aiBackendUrl
        return if (base.isNotEmpty() && BackendUrl.isValid(base)) base else null
    }

    private fun notConfiguredOrInvalid(): Result.Failure {
        val base = prefs.aiBackendUrl
        return if (base.isEmpty()) Result.Failure(Kind.NOT_CONFIGURED)
        else Result.Failure(Kind.INVALID_URL, base, BackendUrl.host(base))
    }

    private suspend fun post(path: String, json: JSONObject): Result {
        val base = checkedBase() ?: return notConfiguredOrInvalid()
        val request = try {
            baseRequest(base + path).post(json.toString().toRequestBody(JSON)).build()
        } catch (e: IllegalArgumentException) {
            return Result.Failure(Kind.INVALID_URL, base, BackendUrl.host(base))
        }
        return execute(request, base) { body -> body.optString("text").takeIf { it.isNotEmpty() } }
    }

    private fun baseRequest(url: String): Request.Builder {
        val builder = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", "RayeanAIKeyboard/${BuildConfig.VERSION_NAME} (Android)")
        val token = prefs.aiBackendToken
        if (token.isNotEmpty()) builder.header("Authorization", "Bearer $token")
        return builder
    }

    private suspend fun execute(request: Request, base: String, parse: (JSONObject) -> String?): Result {
        val host = BackendUrl.host(base)
        val response = try {
            http.newCall(request).await()
        } catch (e: IOException) {
            return Result.Failure(Kind.NETWORK, classify(e).name, host)
        }
        response.use { resp ->
            val bodyText = try {
                resp.body?.string().orEmpty()
            } catch (e: IOException) {
                return Result.Failure(Kind.NETWORK, classify(e).name, host)
            }
            val json = runCatching { JSONObject(bodyText) }.getOrNull()
            if (!resp.isSuccessful) {
                val serverMsg = json?.optString("error")?.takeIf { it.isNotEmpty() }
                val kind = when (resp.code) {
                    401, 403 -> Kind.UNAUTHORIZED
                    413 -> Kind.TOO_LONG
                    429 -> Kind.RATE_LIMITED
                    404 -> if (serverMsg == null) Kind.BAD_RESPONSE else Kind.SERVER
                    else -> if (serverMsg == null && json == null) Kind.BAD_RESPONSE else Kind.SERVER
                }
                return Result.Failure(kind, serverMsg ?: "HTTP ${resp.code}", host)
            }
            if (json == null) return Result.Failure(Kind.BAD_RESPONSE, "HTTP ${resp.code}", host)
            val value = parse(json) ?: return Result.Failure(Kind.BAD_RESPONSE, null, host)
            return Result.Success(value)
        }
    }

    private fun classify(e: IOException): NetworkProblem = when (e) {
        is UnknownHostException -> NetworkProblem.NO_HOST
        is ConnectException, is NoRouteToHostException -> NetworkProblem.REFUSED
        is SSLException -> NetworkProblem.TLS
        is InterruptedIOException -> NetworkProblem.TIMEOUT // includes SocketTimeoutException
        else -> NetworkProblem.OTHER
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) cont.resume(response) else response.close()
            }

            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }
        })
        cont.invokeOnCancellation { runCatching { cancel() } }
    }

    private companion object {
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
