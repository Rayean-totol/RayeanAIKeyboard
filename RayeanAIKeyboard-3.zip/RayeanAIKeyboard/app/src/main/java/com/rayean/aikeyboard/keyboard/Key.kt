package com.rayean.aikeyboard.keyboard

enum class KeyType {
    CHAR, SHIFT, BACKSPACE, ENTER, SPACE,
    MODE_SYMBOLS, MODE_SYMBOLS_2, MODE_ALPHA,
    LANGUAGE, EMOJI,
}

/**
 * One key on the keyboard.
 *
 * @param output       text committed on tap
 * @param shiftOutput  text committed when Shift is active (null = same as [output])
 * @param label        what is drawn on the key (defaults to [output])
 * @param shiftLabel   what is drawn while Shift is active
 * @param longPress    text committed on long-press (also drawn as a small hint)
 * @param width        width in key units (a normal letter key = 1.0)
 * @param longPressLabel hint drawn for [longPress] when the character itself is invisible (e.g. ZWNJ)
 */
data class Key(
    val type: KeyType,
    val output: String = "",
    val shiftOutput: String? = null,
    val label: String = output,
    val shiftLabel: String? = shiftOutput,
    val longPress: String? = null,
    val width: Float = 1f,
    val longPressLabel: String? = null,
) {
    val isFunctional: Boolean get() = type != KeyType.CHAR && type != KeyType.SPACE
    val repeats: Boolean get() = type == KeyType.BACKSPACE

    fun outputFor(shifted: Boolean): String = if (shifted) shiftOutput ?: output else output
    fun labelFor(shifted: Boolean): String = if (shifted) shiftLabel ?: shiftOutput ?: label else label
}

/** A full keyboard page: rows of keys. */
data class KeyboardLayout(
    val id: String,
    val rows: List<List<Key>>,
) {
    /** The widest row determines the size of one key unit, so keys are equal width across rows. */
    val maxRowUnits: Float = rows.maxOf { row -> row.sumOf { it.width.toDouble() }.toFloat() }
}

enum class KeyboardMode { ALPHA, SYMBOLS, SYMBOLS_2, NUMBER, PHONE }

enum class ShiftState { OFF, ON, LOCKED }

/** What the Enter key should look like for the current text field. */
enum class EnterStyle { RETURN, GO, SEARCH, SEND, NEXT, DONE, PREVIOUS }
