package com.rayean.aikeyboard.data

/**
 * Cleans up the backend address the user typed or pasted on a phone:
 *  - "rayean-ai.me.workers.dev"            -> "https://rayean-ai.me.workers.dev"
 *  - "https://host/" or "https://host/health" or ".../v1/fix" -> "https://host"
 */
object BackendUrl {

    private val ENDPOINT_SUFFIXES = listOf("/v1/fix", "/v1/translate", "/health", "/v1")

    fun normalize(input: String?): String {
        var url = input?.trim().orEmpty()
        if (url.isEmpty()) return ""
        url = url.replace(" ", "")
        if (!url.contains("://")) url = "https://$url"
        url = url.trimEnd('/')
        var changed = true
        while (changed) {
            changed = false
            for (suffix in ENDPOINT_SUFFIXES) {
                if (url.endsWith(suffix, ignoreCase = true)) {
                    url = url.dropLast(suffix.length).trimEnd('/')
                    changed = true
                }
            }
        }
        return url
    }

    /** True for http(s) URLs that have a host part. */
    fun isValid(url: String): Boolean {
        val u = normalize(url)
        if (!(u.startsWith("https://", ignoreCase = true) || u.startsWith("http://", ignoreCase = true))) return false
        val host = u.substringAfter("://").substringBefore('/').substringBefore(':')
        return host.isNotEmpty() && (host.contains('.') || host == "localhost")
    }

    /** Host name for messages, e.g. "rayean-ai.me.workers.dev". */
    fun host(url: String): String = normalize(url).substringAfter("://").substringBefore('/')
}
