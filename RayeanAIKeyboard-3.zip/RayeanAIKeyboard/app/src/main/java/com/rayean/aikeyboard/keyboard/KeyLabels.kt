package com.rayean.aikeyboard.keyboard

/**
 * How key labels are drawn (never what is typed).
 *
 * Bengali vowel signs (া ি ী ু ূ ৃ ে ৈ ো ৌ), hasanta (্), chandrabindu (ঁ), anusvara (ং),
 * visarga (ঃ) and nukta (়) are combining marks. Drawn alone, the text shaper treats them as a
 * broken cluster and inserts a dotted circle (◌), often misplaced. Prefixing a NO-BREAK SPACE
 * gives the mark an invisible base, so the key shows only the clean vowel sign.
 * The key still types the plain Unicode mark.
 */
object KeyLabels {

    const val NBSP = " "

    fun isCombiningMark(codePoint: Int): Boolean = when (Character.getType(codePoint)) {
        Character.NON_SPACING_MARK.toInt(),
        Character.COMBINING_SPACING_MARK.toInt(),
        Character.ENCLOSING_MARK.toInt() -> true
        else -> false
    }

    /** Label safe to draw on its own: combining marks get an invisible base. */
    fun display(label: String): String {
        if (label.isEmpty()) return label
        return if (isCombiningMark(label.codePointAt(0))) NBSP + label else label
    }

    fun containsBengali(text: String): Boolean = text.any { it in 'ঀ'..'৿' }
}
