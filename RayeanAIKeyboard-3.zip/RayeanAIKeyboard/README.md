# Rayean AI Keyboard

A real Android system keyboard (`InputMethodService`) for **English, বাংলা and العربية**, with voice typing, AI Fix and translation. Once enabled it works in every app — WhatsApp, Messenger, Facebook, SMS, Chrome, Notes and so on.

## Feature status

| Feature | Status | How it works |
|---|---|---|
| System keyboard (EN / বাংলা / العربية) | ✅ Works | `ime/RayeanImeService.kt` + custom `keyboard/KeyboardView.kt` |
| Letters, numbers row, symbols (2 pages), number/phone pads | ✅ Works | `keyboard/Layouts.kt` |
| Shift / caps lock (double-tap), Backspace (hold to repeat), Enter (Send/Search/Go/Next/Done) | ✅ Works | |
| Language switch key EN → বাং → عربي (long-press = system keyboard picker) | ✅ Works | |
| Emoji panel with recents | ✅ Works | `emoji/` |
| Voice typing (Bangla, English, Arabic) | ✅ Works | Android `SpeechRecognizer`; live words appear in the field while you speak |
| Translate — on-device engine (default) | ✅ Works | Google ML Kit, offline after a one-time ~30 MB language-pack download |
| AI Fix (spelling, grammar, punctuation, Banglish → বাংলা) | ✅ Works once your backend URL is set | Calls your backend in `backend/` (Cloudflare Worker or Node), which holds the AI key |
| Translate — AI engine (optional) | ✅ Same backend | `/v1/translate` |
| Settings screen | ✅ Works | `settings/SettingsActivity.kt` |
| First-time setup (3 steps) | ✅ Works | `setup/SetupActivity.kt` (app launcher icon) |
| Privacy guard | ✅ Works | `privacy/PrivacyGuard.kt` |

Nothing is simulated: without a backend URL, AI Fix says "AI Fix isn't connected yet" with a **Set up** button; if the backend can't be reached it says which address failed and why.

## Build the APK

**Android Studio (easiest):** File → Open → this folder → wait for Gradle sync → **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. The APK is in `app/build/outputs/apk/debug/`.

**GitHub (no Android Studio needed, works from a phone):** put this project in a GitHub repository — either the extracted files, or just `RayeanAIKeyboard.zip` at the repository root plus `.github/workflows/android-build.yml`. The workflow builds the APK on every push to `main` (or manually via **Run workflow**) — open the **Actions** tab → latest run → download the **RayeanAIKeyboard-APK** artifact.

**Command line** (JDK 17 + Android SDK installed):

```bash
./gradlew assembleDebug        # APK
./gradlew testDebugUnitTest    # unit tests
```

Release builds: create `keystore.properties` (storeFile, storePassword, keyAlias, keyPassword) in the project root, then `./gradlew assembleRelease`.

Toolchain: AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, compileSdk/targetSdk 35, minSdk 26 (Android 8.0+).

## Install and set up on the phone

1. Install the APK (allow "Install unknown apps" for your browser/file manager if asked).
2. Open **Rayean AI Keyboard** and follow the 3 steps:
   1. **Enable Rayean AI Keyboard** → turn it on in Android's keyboard list (Android shows its standard warning for every keyboard).
   2. **Select Rayean AI Keyboard** → choose it in the keyboard picker.
   3. **Start typing** → try the test box, and tap **Allow microphone** for voice typing.

Voice typing uses the phone's speech service (normally the Google app). Bangla and Arabic voice need an internet connection on most phones.

## Connect AI Fix

The AI key never goes in the APK. The keyboard calls **your backend**, and the backend calls Claude (or OpenAI / Gemini).

1. Deploy `backend/worker.js` as a free **Cloudflare Worker** from your phone's browser and add the secrets `ANTHROPIC_API_KEY` and `APP_TOKEN` — step by step in [`backend/README.md`](backend/README.md). (Or run `backend/server.js` on any Node 18+ server.)
2. On the phone: keyboard ⚙ → **AI Fix — your backend** → **Backend API URL** = `https://rayean-ai.YOUR-NAME.workers.dev`, **App token** = your `APP_TOKEN`.
3. Tap **Test AI Fix** — it sends "I am go market" to your backend and shows the real answer.

(You can also bake the URL into the build with `rayean.aiBackendUrl=…` in `gradle.properties`.)

## Bangla keyboard notes

- Every key types standard Bengali Unicode in normal form (NFC); য় ড় ঢ় are typed as letter + nukta.
- Vowel-sign keys (া ি ী ু ূ ৃ ে ৈ ো ৌ), ্ ঁ ং ঃ are drawn with the bundled **Noto Sans Bengali** font on an invisible base, so no dotted circle (◌) appears on the keys.
- Conjuncts: consonant + ্ + consonant (ক ্ ষ = ক্ষ). Long-press ্ = ZWNJ (ক্‌ষ), Shift + ঁ = ZWJ (র‍্যাব).
- Backspace removes one vowel sign / hasanta at a time, and য় ড় ঢ় in one press.

Font: Noto Sans Bengali © The Noto Project Authors, SIL Open Font License 1.1 (`app/src/main/assets/licenses/`).

## Privacy

- Password, PIN, OTP, card-number and all numeric/phone fields: **no AI Fix, no translation, no voice** (a 🔒 appears on the toolbar).
- Incognito fields (`IME_FLAG_NO_PERSONALIZED_LEARNING`): no AI Fix or translation.
- Text that looks like a payment card (Luhn check) or a one-time code is refused before anything is sent.
- The keyboard stores no typed text — only settings and recent emoji. Backups are disabled.
- The backend never logs request text.

## Project structure

```
app/src/main/java/com/rayean/aikeyboard/
├── ime/        RayeanImeService (the keyboard), toolbar, safe text replace + undo
├── keyboard/   Key model, EN/BN/AR/symbol layouts, KeyboardView (drawing + touch), themes
├── emoji/      Emoji panel and data
├── voice/      SpeechRecognizer controller, microphone-permission activity
├── ai/         AiBackendClient + clear error messages
├── translate/  ML Kit on-device + backend translation, 6 directions
├── privacy/    PrivacyGuard (sensitive fields and content)
├── settings/   Settings screen
├── setup/      First-time setup + IME status checks
└── data/       Preferences and languages
backend/        worker.js (Cloudflare Worker / Node), server.js (Node runner), offline tests
```

## Testing checklist on a device

- Type in WhatsApp, Messenger, Facebook, SMS, Chrome, Notes; check Enter sends/searches where the app expects it.
- Switch EN → বাংলা → العربية; Shift for Bangla aspirated letters and Arabic harakat/hamza forms.
- Voice: tap 🎤, speak Bangla/English/Arabic, tap **Done**.
- Translate: tap **Translate**, pick a direction (first run downloads the language pack).
- AI Fix with backend: "I am go market" → "I am going to the market."; "ami ajke dokane jabo" → "আমি আজকে দোকানে যাব।"; **Undo** restores the original.
- Password / OTP field: 🔒 shows, mic/AI/Translate are disabled.
