# Rayean AI Keyboard

A real Android system keyboard (`InputMethodService`) for **English, বাংলা and العربية**, with voice typing, AI Fix and translation. Once enabled it works in every app — WhatsApp, Messenger, Facebook, SMS, Chrome, Notes and so on.

## Feature status

| Feature | Status | How it works |
|---|---|---|
| System keyboard (EN / বাংলা / العربية) | ✅ Works | `ime/RayeanImeService.kt` + custom `keyboard/KeyboardView.kt` |
| Letters, numbers row, symbols (2 pages), number/phone pads | ✅ Works | `keyboard/Layouts.kt` |
| Shift / caps lock (double-tap), Backspace (hold to repeat), Enter (Send/Search/Go/Next/Done) | ✅ Works | |
| Language switch key EN → বাং → عربي (long-press = system keyboard picker) | ✅ Works | |
| Emoji panel with recents | ✅ Works | `emoji/` |
| Voice typing (Bangla, English, Arabic) | ✅ Works | Android `SpeechRecognizer`; live words appear in the field while you speak |
| Translate — on-device engine (default) | ✅ Works | Google ML Kit, offline after a one-time ~30 MB language-pack download |
| AI Fix (spelling, grammar, punctuation, Banglish → বাংলা) | ⚠️ **NEEDS_API** | Calls your backend in `backend/` (holds the Claude API key) |
| Translate — AI engine (optional) | ⚠️ **NEEDS_API** | Same backend, `/v1/translate` |
| Settings screen | ✅ Works | `settings/SettingsActivity.kt` |
| First-time setup (3 steps) | ✅ Works | `setup/SetupActivity.kt` (app launcher icon) |
| Privacy guard | ✅ Works | `privacy/PrivacyGuard.kt` |

Nothing is simulated: if the backend URL is empty, AI Fix shows "AI backend not set up (NEEDS_API)" instead of pretending.

## Build the APK

**Android Studio (easiest):** File → Open → this folder → wait for Gradle sync → **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. The APK is in `app/build/outputs/apk/debug/`.

**GitHub (no Android Studio needed, works from a phone):** put this project in a GitHub repository — either the extracted files, or just `RayeanAIKeyboard.zip` at the repository root plus `.github/workflows/android-build.yml`. The workflow builds the APK on every push to `main` (or manually via **Run workflow**) — open the **Actions** tab → latest run → download the **RayeanAIKeyboard-APK** artifact.

**Command line** (JDK 17 + Android SDK installed):

```bash
./gradlew assembleDebug        # APK
./gradlew testDebugUnitTest    # unit tests
```

Release builds: create `keystore.properties` (storeFile, storePassword, keyAlias, keyPassword) in the project root, then `./gradlew assembleRelease`.

Toolchain: AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, compileSdk/targetSdk 35, minSdk 26 (Android 8.0+).

## Install and set up on the phone

1. Install the APK (allow "Install unknown apps" for your browser/file manager if asked).
2. Open **Rayean AI Keyboard** and follow the 3 steps:
   1. **Enable Rayean AI Keyboard** → turn it on in Android's keyboard list (Android shows its standard warning for every keyboard).
   2. **Select Rayean AI Keyboard** → choose it in the keyboard picker.
   3. **Start typing** → try the test box, and tap **Allow microphone** for voice typing.

Voice typing uses the phone's speech service (normally the Google app). Bangla and Arabic voice need an internet connection on most phones.

## Connect AI Fix (NEEDS_API)

1. Deploy the backend in `backend/` (Node 18+, zero dependencies) with your `ANTHROPIC_API_KEY` — see [`backend/README.md`](backend/README.md).
2. On the phone: keyboard ⚙ → **AI backend URL** = `https://your-server…`, **AI backend app token** = your `APP_TOKEN`, then **Test AI backend**.
   (Or bake the URL into the build: `rayean.aiBackendUrl=…` in `gradle.properties`, or the `RAYEAN_AI_BACKEND_URL` repository variable on GitHub.)

The API key stays on your server — it is never put in the APK.

## Privacy

- Password, PIN, OTP, card-number and all numeric/phone fields: **no AI Fix, no translation, no voice** (a 🔒 appears on the toolbar).
- Incognito fields (`IME_FLAG_NO_PERSONALIZED_LEARNING`): no AI Fix or translation.
- Text that looks like a payment card (Luhn check) or a one-time code is refused before anything is sent.
- The keyboard stores no typed text — only settings and recent emoji. Backups are disabled.
- The backend never logs request text.

## Project structure

```
app/src/main/java/com/rayean/aikeyboard/
├── ime/        RayeanImeService (the keyboard), toolbar, safe text replace + undo
├── keyboard/   Key model, EN/BN/AR/symbol layouts, KeyboardView (drawing + touch), themes
├── emoji/      Emoji panel and data
├── voice/      SpeechRecognizer controller, microphone-permission activity
├── ai/         AiBackendClient (NEEDS_API)
├── translate/  ML Kit on-device + backend translation, 6 directions
├── privacy/    PrivacyGuard (sensitive fields and content)
├── settings/   Settings screen
├── setup/      First-time setup + IME status checks
└── data/       Preferences and languages
backend/        Reference AI server (Node) + offline tests
```

## Testing checklist on a device

- Type in WhatsApp, Messenger, Facebook, SMS, Chrome, Notes; check Enter sends/searches where the app expects it.
- Switch EN → বাংলা → العربية; Shift for Bangla aspirated letters and Arabic harakat/hamza forms.
- Voice: tap 🎤, speak Bangla/English/Arabic, tap **Done**.
- Translate: tap **Translate**, pick a direction (first run downloads the language pack).
- AI Fix with backend: "I am go market" → "I am going to the market."; "ami ajke dokane jabo" → "আমি আজকে দোকানে যাব।"; **Undo** restores the original.
- Password / OTP field: 🔒 shows, mic/AI/Translate are disabled.
