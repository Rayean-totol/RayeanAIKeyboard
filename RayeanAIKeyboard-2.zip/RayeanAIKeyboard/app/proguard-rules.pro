# Rayean AI Keyboard ProGuard / R8 rules

# The input method service and activities are referenced from the manifest (kept by default).

# OkHttp / Okio
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# ML Kit ships its own consumer rules.
