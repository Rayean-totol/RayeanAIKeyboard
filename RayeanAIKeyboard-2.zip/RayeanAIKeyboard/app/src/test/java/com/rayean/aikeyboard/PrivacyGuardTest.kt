package com.rayean.aikeyboard

import android.text.InputType
import android.view.inputmethod.EditorInfo
import com.rayean.aikeyboard.privacy.PrivacyGuard
import com.rayean.aikeyboard.privacy.PrivacyGuard.Level
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PrivacyGuardTest {

    private fun field(type: Int, hint: String? = null, imeOptions: Int = 0) = EditorInfo().apply {
        inputType = type
        hintText = hint
        this.imeOptions = imeOptions
    }

    private val text = InputType.TYPE_CLASS_TEXT

    @Test
    fun passwordFieldsArePrivate() {
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text or InputType.TYPE_TEXT_VARIATION_PASSWORD)))
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)))
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text or InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)))
    }

    @Test
    fun numberAndPhoneFieldsArePrivate() {
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(InputType.TYPE_CLASS_NUMBER)))
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(InputType.TYPE_CLASS_PHONE)))
    }

    @Test
    fun sensitiveHintsArePrivate() {
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text, "Enter PIN")))
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text, "OTP code")))
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text, "Card number")))
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text, "পাসওয়ার্ড দিন")))
        assertEquals(Level.PRIVATE, PrivacyGuard.classify(field(text, "رمز التحقق")))
    }

    @Test
    fun ordinaryFieldsAreNormal() {
        assertEquals(Level.NORMAL, PrivacyGuard.classify(field(text, "Type a message")))
        assertEquals(Level.NORMAL, PrivacyGuard.classify(field(text, "Choose from spinner"))) // "pin" inside a word
    }

    @Test
    fun incognitoFieldsBlockAi() {
        val f = field(text, "Search", EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING)
        assertEquals(Level.INCOGNITO, PrivacyGuard.classify(f))
    }

    @Test
    fun detectsCardNumbers() {
        assertTrue(PrivacyGuard.containsSensitiveData("my card 4111 1111 1111 1111 thanks"))
        assertTrue(PrivacyGuard.containsSensitiveData("5500-0000-0000-0004"))
        assertFalse(PrivacyGuard.containsSensitiveData("order 1234 5678 9012 3456")) // fails Luhn
    }

    @Test
    fun detectsOneTimeCodes() {
        assertTrue(PrivacyGuard.containsSensitiveData("Your OTP is 482913"))
        assertTrue(PrivacyGuard.containsSensitiveData("Verification code: 7731"))
        assertTrue(PrivacyGuard.containsSensitiveData("আপনার ওটিপি ৪৮২৯১৩"))
        assertTrue(PrivacyGuard.containsSensitiveData("رمز التحقق ٤٨٢٩١٣"))
    }

    @Test
    fun ordinaryTextIsAllowed() {
        assertFalse(PrivacyGuard.containsSensitiveData("I am go market"))
        assertFalse(PrivacyGuard.containsSensitiveData("ami ajke dokane jabo"))
        assertFalse(PrivacyGuard.containsSensitiveData("I was spinning around in 2024"))
        assertFalse(PrivacyGuard.containsSensitiveData("Meet me at 5 pm, room 1204"))
    }
}
