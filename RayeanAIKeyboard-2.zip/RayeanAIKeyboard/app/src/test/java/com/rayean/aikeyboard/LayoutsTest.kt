package com.rayean.aikeyboard

import com.rayean.aikeyboard.data.KeyboardLanguage
import com.rayean.aikeyboard.keyboard.KeyType
import com.rayean.aikeyboard.keyboard.KeyboardMode
import com.rayean.aikeyboard.keyboard.Layouts
import com.rayean.aikeyboard.translate.TranslationDirection
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LayoutsTest {

    @Test
    fun everyAlphaLayoutHasTheRequiredKeys() {
        for (lang in KeyboardLanguage.entries) {
            for (numberRow in listOf(true, false)) {
                val layout = Layouts.build(lang, KeyboardMode.ALPHA, numberRow)
                val types = layout.rows.flatten().map { it.type }.toSet()
                for (required in listOf(
                    KeyType.SHIFT, KeyType.BACKSPACE, KeyType.ENTER, KeyType.SPACE,
                    KeyType.LANGUAGE, KeyType.EMOJI, KeyType.MODE_SYMBOLS,
                )) {
                    assertTrue("$lang/$numberRow missing $required", required in types)
                }
                assertEquals(if (numberRow) 5 else 4, layout.rows.size)
            }
        }
    }

    @Test
    fun rowsFitInsideTheLayoutWidth() {
        for (lang in KeyboardLanguage.entries) for (mode in KeyboardMode.entries) {
            val layout = Layouts.build(lang, mode, numberRow = true)
            for (row in layout.rows) {
                val units = row.sumOf { it.width.toDouble() }
                assertTrue("$lang/$mode row too wide", units <= layout.maxRowUnits + 0.001)
            }
            layout.rows.flatten().filter { it.type == KeyType.CHAR }.forEach {
                assertTrue("$lang/$mode empty key", it.output.isNotEmpty())
            }
        }
    }

    @Test
    fun banglaShiftGivesAspiratedLetters() {
        val keys = Layouts.build(KeyboardLanguage.BANGLA, KeyboardMode.ALPHA, false).rows.flatten()
        val k = keys.first { it.output == "ক" }
        assertEquals("খ", k.outputFor(shifted = true))
        assertTrue(keys.any { it.output == "।" })
    }

    @Test
    fun englishShiftUppercases() {
        val q = Layouts.build(KeyboardLanguage.ENGLISH, KeyboardMode.ALPHA, true).rows.flatten().first { it.output == "q" }
        assertEquals("Q", q.outputFor(true))
    }

    @Test
    fun arabicHasNativeCommaAndHarakat() {
        val keys = Layouts.build(KeyboardLanguage.ARABIC, KeyboardMode.ALPHA, true).rows.flatten()
        assertTrue(keys.any { it.output == "،" })
        assertTrue(keys.any { it.shiftOutput == "َ" }) // fatha
    }

    @Test
    fun numberPadUsesWesternDigits() {
        val keys = Layouts.build(KeyboardLanguage.BANGLA, KeyboardMode.NUMBER, true).rows.flatten()
        assertTrue(keys.any { it.output == "5" })
    }

    @Test
    fun sixTranslationDirections() {
        val dirs = TranslationDirection.entries
        assertEquals(6, dirs.size)
        assertEquals(6, dirs.map { it.from to it.to }.toSet().size)
        assertTrue(dirs.none { it.from == it.to })
        assertEquals(TranslationDirection.BN_EN, TranslationDirection.fromName("nonsense"))
    }
}
