package com.rayean.aikeyboard.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.rayean.aikeyboard.R

/**
 * Real speech-to-text using Android's [SpeechRecognizer] (the device's speech service,
 * usually Google). Partial results stream in while the user talks; the final result is
 * handed back for insertion into the current text field.
 *
 * Must be used from the main thread.
 */
class VoiceInputController(
    private val context: Context,
    private val callback: Callback,
) : RecognitionListener {

    interface Callback {
        fun onVoiceReady()
        fun onVoicePartial(text: String)
        fun onVoiceFinal(text: String)
        fun onVoiceError(message: String)
        fun onVoiceEnded()
    }

    private var recognizer: SpeechRecognizer? = null
    var isListening: Boolean = false
        private set

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /** @param languageTag BCP-47 tag such as "bn-BD", "en-US" or "ar-SA". */
    fun start(languageTag: String) {
        if (isListening) return
        val rec = recognizer ?: SpeechRecognizer.createSpeechRecognizer(context).also {
            it.setRecognitionListener(this)
            recognizer = it
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            // Give the user time to think between words before the session ends.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
        isListening = true
        try {
            rec.startListening(intent)
        } catch (e: Exception) {
            isListening = false
            reset()
            callback.onVoiceError(context.getString(R.string.voice_error_client))
            callback.onVoiceEnded()
        }
    }

    /** Stop listening and deliver whatever was heard. */
    fun stop() {
        recognizer?.stopListening()
    }

    /** Abort without delivering results. */
    fun cancel() {
        if (!isListening) return
        isListening = false
        recognizer?.cancel()
        callback.onVoiceEnded()
    }

    fun destroy() {
        isListening = false
        reset()
    }

    private fun reset() {
        recognizer?.destroy()
        recognizer = null
    }

    // ---------------- RecognitionListener ----------------

    override fun onReadyForSpeech(params: Bundle?) = callback.onVoiceReady()
    override fun onBeginningOfSpeech() = Unit
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    override fun onPartialResults(partialResults: Bundle?) {
        val text = partialResults
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            ?.trim()
        if (!text.isNullOrEmpty() && isListening) callback.onVoicePartial(text)
    }

    override fun onResults(results: Bundle?) {
        val text = results
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()
            ?.trim()
        val wasListening = isListening
        isListening = false
        if (wasListening) {
            if (text.isNullOrEmpty()) callback.onVoiceError(context.getString(R.string.voice_error_no_match))
            else callback.onVoiceFinal(text)
            callback.onVoiceEnded()
        }
    }

    override fun onError(error: Int) {
        val wasListening = isListening
        isListening = false
        // Some recognition services are left in a bad state after errors; start fresh next time.
        reset()
        if (!wasListening) return
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> R.string.voice_error_no_match
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> R.string.voice_error_network
            SpeechRecognizer.ERROR_AUDIO -> R.string.voice_error_audio
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> R.string.voice_error_permission
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> R.string.voice_error_busy
            ERROR_LANGUAGE_NOT_SUPPORTED, ERROR_LANGUAGE_UNAVAILABLE -> R.string.voice_error_language
            ERROR_TOO_MANY_REQUESTS -> R.string.voice_error_busy
            SpeechRecognizer.ERROR_SERVER -> R.string.voice_error_server
            else -> R.string.voice_error_client
        }
        callback.onVoiceError(context.getString(msg))
        callback.onVoiceEnded()
    }

    private companion object {
        // Values from SpeechRecognizer (API 31+), inlined so they compile against minSdk 26.
        const val ERROR_TOO_MANY_REQUESTS = 10
        const val ERROR_LANGUAGE_NOT_SUPPORTED = 12
        const val ERROR_LANGUAGE_UNAVAILABLE = 13
    }
}
