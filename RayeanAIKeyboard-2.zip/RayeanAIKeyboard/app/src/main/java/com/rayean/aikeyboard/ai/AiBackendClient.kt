package com.rayean.aikeyboard.ai

import com.rayean.aikeyboard.BuildConfig
import com.rayean.aikeyboard.data.Prefs
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * NEEDS_API — client for the Rayean AI backend (reference server in /backend).
 *
 * The app never talks to an LLM provider directly, so no provider API key ships inside
 * the APK. The backend holds the key and exposes two endpoints:
 *
 *   POST {baseUrl}/v1/fix        {"text": "...", "keyboard_language": "en|bn|ar"}  -> {"text": "..."}
 *   POST {baseUrl}/v1/translate  {"text": "...", "source": "bn", "target": "en"}   -> {"text": "..."}
 *   GET  {baseUrl}/health                                                         -> {"ok": true}
 *
 * Optional header: Authorization: Bearer <app token>  (Settings → AI backend token)
 */
class AiBackendClient(private val prefs: Prefs) {

    sealed class Result {
        data class Success(val text: String) : Result()
        data class Failure(val kind: Kind, val detail: String? = null) : Result()
    }

    enum class Kind { NOT_CONFIGURED, NETWORK, UNAUTHORIZED, RATE_LIMITED, TOO_LONG, SERVER, BAD_RESPONSE }

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    val isConfigured: Boolean get() = prefs.aiBackendUrl.isNotEmpty()

    suspend fun fix(text: String, keyboardLanguage: String): Result =
        post("/v1/fix", JSONObject().put("text", text).put("keyboard_language", keyboardLanguage))

    suspend fun translate(text: String, source: String, target: String): Result =
        post("/v1/translate", JSONObject().put("text", text).put("source", source).put("target", target))

    suspend fun health(): Result {
        val base = prefs.aiBackendUrl
        if (base.isEmpty()) return Result.Failure(Kind.NOT_CONFIGURED)
        val request = try {
            baseRequest("$base/health").get().build()
        } catch (e: IllegalArgumentException) {
            return Result.Failure(Kind.NOT_CONFIGURED, e.message)
        }
        return execute(request) { body -> if (body.optBoolean("ok")) "ok" else null }
    }

    private suspend fun post(path: String, json: JSONObject): Result {
        val base = prefs.aiBackendUrl
        if (base.isEmpty()) return Result.Failure(Kind.NOT_CONFIGURED)
        val request = try {
            baseRequest(base + path)
                .post(json.toString().toRequestBody(JSON))
                .build()
        } catch (e: IllegalArgumentException) {
            return Result.Failure(Kind.NOT_CONFIGURED, e.message) // malformed URL
        }
        return execute(request) { body -> body.optString("text").takeIf { it.isNotEmpty() } }
    }

    private fun baseRequest(url: String): Request.Builder {
        val builder = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .header("User-Agent", "RayeanAIKeyboard/${BuildConfig.VERSION_NAME} (Android)")
        val token = prefs.aiBackendToken
        if (token.isNotEmpty()) builder.header("Authorization", "Bearer $token")
        return builder
    }

    private suspend fun execute(request: Request, parse: (JSONObject) -> String?): Result {
        val response = try {
            http.newCall(request).await()
        } catch (e: IOException) {
            return Result.Failure(Kind.NETWORK, e.message)
        }
        response.use { resp ->
            val bodyText = try {
                resp.body?.string().orEmpty()
            } catch (e: IOException) {
                return Result.Failure(Kind.NETWORK, e.message)
            }
            if (!resp.isSuccessful) {
                val kind = when (resp.code) {
                    401, 403 -> Kind.UNAUTHORIZED
                    413 -> Kind.TOO_LONG
                    429 -> Kind.RATE_LIMITED
                    else -> Kind.SERVER
                }
                val serverMsg = runCatching { JSONObject(bodyText).optString("error") }.getOrNull()
                return Result.Failure(kind, serverMsg?.takeIf { it.isNotEmpty() } ?: "HTTP ${resp.code}")
            }
            val json = try {
                JSONObject(bodyText)
            } catch (e: Exception) {
                return Result.Failure(Kind.BAD_RESPONSE)
            }
            val value = parse(json) ?: return Result.Failure(Kind.BAD_RESPONSE)
            return Result.Success(value)
        }
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        enqueue(object : Callback {
            override fun onResponse(call: Call, response: Response) {
                cont.resume(response)
            }

            override fun onFailure(call: Call, e: IOException) {
                if (!cont.isCancelled) cont.resumeWithException(e)
            }
        })
        cont.invokeOnCancellation { runCatching { cancel() } }
    }

    private companion object {
        val JSON = "application/json; charset=utf-8".toMediaType()
    }
}
