package com.rayean.aikeyboard.ime

import android.view.inputmethod.ExtractedTextRequest
import android.view.inputmethod.InputConnection

/**
 * Reads the text that AI Fix / Translate should work on and writes the result back
 * into the app's text field through the [InputConnection].
 *
 * Target: the current selection if there is one, otherwise the whole field.
 * Before replacing, the field is re-read; if the user changed the text while the
 * request was running, nothing is overwritten.
 */
object EditorText {

    const val MAX_CHARS = 4000

    /** Where the target text came from, so it can be replaced safely later. */
    sealed class Target {
        abstract val text: String

        /** Exact range known (from ExtractedText). */
        data class Range(override val text: String, val start: Int, val end: Int, val isSelection: Boolean) : Target()

        /** Selection without known offsets (editor did not provide ExtractedText). */
        data class Selection(override val text: String) : Target()

        /** Whole field around the cursor without known offsets. */
        data class AroundCursor(override val text: String, val before: String, val after: String) : Target()
    }

    sealed class Capture {
        data class Ok(val target: Target) : Capture()
        data object Empty : Capture()
        data object TooLong : Capture()
    }

    fun capture(ic: InputConnection): Capture {
        val extracted = try {
            ic.getExtractedText(ExtractedTextRequest(), 0)
        } catch (e: Exception) {
            null
        }
        if (extracted?.text != null) {
            val full = extracted.text.toString()
            val s = minOf(extracted.selectionStart, extracted.selectionEnd)
            val e = maxOf(extracted.selectionStart, extracted.selectionEnd)
            if (s in 0..full.length && e in s..full.length && s != e) {
                val sel = full.substring(s, e)
                if (sel.isBlank()) return Capture.Empty
                if (sel.length > MAX_CHARS) return Capture.TooLong
                return Capture.Ok(Target.Range(sel, extracted.startOffset + s, extracted.startOffset + e, isSelection = true))
            }
            if (full.isBlank()) return Capture.Empty
            if (full.length > MAX_CHARS) return Capture.TooLong
            return Capture.Ok(Target.Range(full, extracted.startOffset, extracted.startOffset + full.length, isSelection = false))
        }

        // Fallback for editors that do not support ExtractedText.
        val selected = ic.getSelectedText(0)?.toString()
        if (!selected.isNullOrEmpty()) {
            if (selected.isBlank()) return Capture.Empty
            if (selected.length > MAX_CHARS) return Capture.TooLong
            return Capture.Ok(Target.Selection(selected))
        }
        val before = ic.getTextBeforeCursor(MAX_CHARS + 1, 0)?.toString().orEmpty()
        val after = ic.getTextAfterCursor(MAX_CHARS + 1, 0)?.toString().orEmpty()
        val all = before + after
        if (all.isBlank()) return Capture.Empty
        if (all.length > MAX_CHARS) return Capture.TooLong
        return Capture.Ok(Target.AroundCursor(all, before, after))
    }

    /** Information needed to undo a replacement. */
    data class Undo(val original: String, val replacement: String, val start: Int)

    /**
     * Replaces [target] with [replacement]. Returns an [Undo] record (or null when undo is not
     * possible), or throws [StaleTextException] if the field changed in the meantime.
     */
    fun replace(ic: InputConnection, target: Target, replacement: String): Undo? {
        ic.beginBatchEdit()
        try {
            when (target) {
                is Target.Range -> {
                    val et = ic.getExtractedText(ExtractedTextRequest(), 0) ?: throw StaleTextException()
                    val current = et.text?.toString() ?: throw StaleTextException()
                    val rs = target.start - et.startOffset
                    val re = target.end - et.startOffset
                    if (rs < 0 || re > current.length || current.substring(rs, re) != target.text) {
                        throw StaleTextException()
                    }
                    ic.finishComposingText()
                    ic.setSelection(target.start, target.end)
                    ic.commitText(replacement, 1)
                    return Undo(target.text, replacement, target.start)
                }
                is Target.Selection -> {
                    if (ic.getSelectedText(0)?.toString() != target.text) throw StaleTextException()
                    ic.finishComposingText()
                    ic.commitText(replacement, 1)
                    return null
                }
                is Target.AroundCursor -> {
                    val before = ic.getTextBeforeCursor(MAX_CHARS + 1, 0)?.toString().orEmpty()
                    val after = ic.getTextAfterCursor(MAX_CHARS + 1, 0)?.toString().orEmpty()
                    if (before != target.before || after != target.after) throw StaleTextException()
                    ic.finishComposingText()
                    ic.deleteSurroundingText(before.length, after.length)
                    ic.commitText(replacement, 1)
                    return null
                }
            }
        } finally {
            ic.endBatchEdit()
        }
    }

    /** Puts the original text back if the replaced text is still unchanged. */
    fun undo(ic: InputConnection, undo: Undo): Boolean {
        ic.beginBatchEdit()
        try {
            val et = ic.getExtractedText(ExtractedTextRequest(), 0) ?: return false
            val current = et.text?.toString() ?: return false
            val end = undo.start + undo.replacement.length
            val rs = undo.start - et.startOffset
            val re = end - et.startOffset
            if (rs < 0 || re > current.length || current.substring(rs, re) != undo.replacement) return false
            ic.finishComposingText()
            ic.setSelection(undo.start, end)
            ic.commitText(undo.original, 1)
            return true
        } finally {
            ic.endBatchEdit()
        }
    }

    class StaleTextException : Exception("The text changed while the request was running")
}
