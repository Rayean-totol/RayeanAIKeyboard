package com.rayean.aikeyboard.ime

import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.rayean.aikeyboard.R
import com.rayean.aikeyboard.keyboard.KeyboardTheme
import com.rayean.aikeyboard.privacy.PrivacyGuard
import com.rayean.aikeyboard.translate.TranslationDirection

/**
 * The strip above the keys. It has three modes that share the same height
 * (so the keyboard never jumps): action buttons, a status line, and the
 * translation-direction chips.
 */
class KeyboardToolbar(root: View, private val listener: Listener) {

    interface Listener {
        fun onMicClicked()
        fun onAiFixClicked()
        fun onTranslateClicked()
        fun onSettingsClicked()
        fun onTranslateDirectionChosen(direction: TranslationDirection)
    }

    private val context = root.context
    private val dp = context.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    private val toolbar: View = root.findViewById(R.id.toolbar)
    private val actions: View = root.findViewById(R.id.toolbar_actions)
    private val statusRow: View = root.findViewById(R.id.toolbar_status)
    private val translateRow: View = root.findViewById(R.id.toolbar_translate)

    private val mic: ImageButton = root.findViewById(R.id.btn_mic)
    private val aiFix: TextView = root.findViewById(R.id.btn_ai_fix)
    private val translate: TextView = root.findViewById(R.id.btn_translate)
    private val settings: ImageButton = root.findViewById(R.id.btn_settings)
    private val privacyBadge: ImageView = root.findViewById(R.id.privacy_badge)

    private val statusProgress: ProgressBar = root.findViewById(R.id.status_progress)
    private val statusIcon: ImageView = root.findViewById(R.id.status_icon)
    private val statusText: TextView = root.findViewById(R.id.status_text)
    private val statusAction: TextView = root.findViewById(R.id.status_action)
    private val statusClose: ImageButton = root.findViewById(R.id.status_close)

    private val chips: LinearLayout = root.findViewById(R.id.translate_chips)
    private val translateClose: ImageButton = root.findViewById(R.id.translate_close)

    private var theme = KeyboardTheme.LIGHT
    private var listening = false
    private var onStatusAction: (() -> Unit)? = null
    private var onStatusClose: (() -> Unit)? = null
    private val autoHide = Runnable { showActions() }

    /** Identifies what the status line is currently showing (voice, ai, info). */
    var statusTag: String? = null
        private set

    init {
        mic.setOnClickListener { listener.onMicClicked() }
        aiFix.setOnClickListener { listener.onAiFixClicked() }
        translate.setOnClickListener { listener.onTranslateClicked() }
        settings.setOnClickListener { listener.onSettingsClicked() }
        statusAction.setOnClickListener { onStatusAction?.invoke() }
        statusClose.setOnClickListener {
            val close = onStatusClose
            showActions()
            close?.invoke()
        }
        translateClose.setOnClickListener { showActions() }
        mic.scaleType = ImageView.ScaleType.CENTER
        settings.scaleType = ImageView.ScaleType.CENTER
    }

    fun applyTheme(t: KeyboardTheme) {
        theme = t
        toolbar.setBackgroundColor(t.background)
        val iconTint = ColorStateList.valueOf(t.toolbarIcon)
        settings.imageTintList = iconTint
        privacyBadge.imageTintList = iconTint
        statusClose.imageTintList = iconTint
        translateClose.imageTintList = iconTint
        statusIcon.imageTintList = ColorStateList.valueOf(t.accent)
        statusText.setTextColor(t.keyText)
        statusProgress.indeterminateTintList = ColorStateList.valueOf(t.accent)

        aiFix.background = pill(t.accent)
        aiFix.setTextColor(t.onAccent)
        setStartIcon(aiFix, R.drawable.ic_ai_fix, t.onAccent)

        translate.background = pill(t.key)
        translate.setTextColor(t.keyText)
        setStartIcon(translate, R.drawable.ic_translate, t.keyText)

        statusAction.background = pill(t.key)
        statusAction.setTextColor(t.accent)
        updateMicStyle()
    }

    private fun pill(color: Int) = GradientDrawable().apply {
        cornerRadius = 17 * dp
        setColor(color)
    }

    private fun setStartIcon(tv: TextView, res: Int, tint: Int) {
        val d = ContextCompat.getDrawable(context, res)!!.mutate()
        val size = (18 * dp).toInt()
        d.setBounds(0, 0, size, size)
        d.setTint(tint)
        tv.setCompoundDrawablesRelative(d, null, null, null)
    }

    private fun updateMicStyle() {
        if (listening) {
            mic.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(theme.accent)
            }
            mic.imageTintList = ColorStateList.valueOf(theme.onAccent)
        } else {
            mic.background = null
            mic.imageTintList = ColorStateList.valueOf(theme.toolbarIcon)
        }
    }

    fun setListening(value: Boolean) {
        listening = value
        updateMicStyle()
    }

    /** Dims or hides features that are not allowed in the current field. */
    fun setFieldState(level: PrivacyGuard.Level, aiEnabled: Boolean) {
        val isPrivate = level == PrivacyGuard.Level.PRIVATE
        val restricted = level != PrivacyGuard.Level.NORMAL
        mic.alpha = if (isPrivate) DIMMED else 1f
        aiFix.visibility = if (aiEnabled) View.VISIBLE else View.GONE
        aiFix.alpha = if (restricted) DIMMED else 1f
        translate.alpha = if (restricted) DIMMED else 1f
        privacyBadge.visibility = if (restricted) View.VISIBLE else View.GONE
    }

    fun showActions() {
        handler.removeCallbacks(autoHide)
        statusTag = null
        onStatusAction = null
        onStatusClose = null
        actions.visibility = View.VISIBLE
        statusRow.visibility = View.GONE
        translateRow.visibility = View.GONE
    }

    /**
     * @param tag        what this status belongs to (see constants)
     * @param progress   show a spinner instead of an icon
     * @param iconRes    optional icon when not in progress
     * @param actionLabel optional button (e.g. Undo, Stop)
     * @param autoHideMs return to the action buttons after this delay (0 = stay)
     */
    fun showStatus(
        message: String,
        tag: String = TAG_INFO,
        progress: Boolean = false,
        iconRes: Int = 0,
        actionLabel: String? = null,
        onAction: (() -> Unit)? = null,
        onClose: (() -> Unit)? = null,
        autoHideMs: Long = 0L,
    ) {
        handler.removeCallbacks(autoHide)
        statusTag = tag
        actions.visibility = View.GONE
        translateRow.visibility = View.GONE
        statusRow.visibility = View.VISIBLE

        statusProgress.visibility = if (progress) View.VISIBLE else View.GONE
        if (!progress && iconRes != 0) {
            statusIcon.setImageResource(iconRes)
            statusIcon.visibility = View.VISIBLE
        } else {
            statusIcon.visibility = View.GONE
        }
        statusText.text = message
        statusAction.text = actionLabel.orEmpty()
        statusAction.visibility = if (actionLabel != null) View.VISIBLE else View.GONE
        onStatusAction = onAction
        onStatusClose = onClose
        if (autoHideMs > 0) handler.postDelayed(autoHide, autoHideMs)
    }

    fun updateStatusText(message: String) {
        statusText.text = message
    }

    fun showTranslateDirections(selected: TranslationDirection) {
        handler.removeCallbacks(autoHide)
        statusTag = null
        actions.visibility = View.GONE
        statusRow.visibility = View.GONE
        translateRow.visibility = View.VISIBLE
        chips.removeAllViews()
        for (direction in TranslationDirection.entries) {
            val chip = TextView(context)
            chip.text = direction.label
            chip.gravity = Gravity.CENTER
            chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            chip.setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), 0)
            val isSelected = direction == selected
            chip.background = pill(if (isSelected) theme.accent else theme.key)
            chip.setTextColor(if (isSelected) theme.onAccent else theme.keyText)
            chip.setOnClickListener { listener.onTranslateDirectionChosen(direction) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (32 * dp).toInt())
            lp.marginEnd = (6 * dp).toInt()
            chips.addView(chip, lp)
        }
    }

    companion object {
        const val TAG_INFO = "info"
        const val TAG_VOICE = "voice"
        const val TAG_AI = "ai"
        private const val DIMMED = 0.35f
    }
}
