package com.rayean.aikeyboard.voice

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.widget.Toast
import com.rayean.aikeyboard.R

/**
 * A keyboard (InputMethodService) cannot show the runtime-permission dialog itself,
 * so this invisible activity asks for the microphone permission on its behalf.
 * After the user allows it, the keyboard starts listening automatically when it
 * reappears (see [VoicePermission.consumePendingStart]).
 */
class MicPermissionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (VoicePermission.isGranted(this)) {
            finish()
            return
        }
        if (savedInstanceState == null) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_CODE)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            if (granted) {
                VoicePermission.markPendingStart(intent.getBooleanExtra(EXTRA_START_AFTER, false))
            } else {
                Toast.makeText(this, R.string.voice_permission_denied, Toast.LENGTH_LONG).show()
            }
        }
        finish()
    }

    companion object {
        private const val REQUEST_CODE = 42
        const val EXTRA_START_AFTER = "start_after"

        fun createIntent(context: Context, startListeningAfter: Boolean): Intent =
            Intent(context, MicPermissionActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .putExtra(EXTRA_START_AFTER, startListeningAfter)
    }
}

/** Shared microphone-permission helpers for the keyboard, settings and setup screens. */
object VoicePermission {
    private var pendingStartAt = 0L

    fun isGranted(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun markPendingStart(start: Boolean) {
        pendingStartAt = if (start) SystemClock.elapsedRealtime() else 0L
    }

    /** True once if the user just granted the permission from the keyboard's mic button. */
    fun consumePendingStart(): Boolean {
        val recent = pendingStartAt != 0L && SystemClock.elapsedRealtime() - pendingStartAt < 30_000L
        pendingStartAt = 0L
        return recent
    }
}
