package com.rayean.aikeyboard.keyboard

import com.rayean.aikeyboard.data.KeyboardLanguage
import java.util.Locale

/**
 * Keyboard layouts for English (QWERTY), Bangla (Probhat-style phonetic positions)
 * and Arabic (standard Arabic mobile layout), plus symbol and number pages.
 */
object Layouts {

    // ---------- key helpers ----------
    private fun ch(out: String, shift: String? = null, long: String? = null, label: String = out, shiftLabel: String? = shift) =
        Key(KeyType.CHAR, output = out, shiftOutput = shift, label = label, shiftLabel = shiftLabel, longPress = long)

    private fun latin(c: String, long: String?) = ch(c, c.uppercase(Locale.ROOT), long)

    private fun shiftKey(w: Float) = Key(KeyType.SHIFT, width = w)
    private fun backspace(w: Float) = Key(KeyType.BACKSPACE, width = w)

    private val WESTERN_DIGITS = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    private val BANGLA_DIGITS = listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "০")
    private val ARABIC_DIGITS = listOf("١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩", "٠")

    private fun nativeDigits(lang: KeyboardLanguage) = when (lang) {
        KeyboardLanguage.ENGLISH -> WESTERN_DIGITS
        KeyboardLanguage.BANGLA -> BANGLA_DIGITS
        KeyboardLanguage.ARABIC -> ARABIC_DIGITS
    }

    fun build(lang: KeyboardLanguage, mode: KeyboardMode, numberRow: Boolean): KeyboardLayout = when (mode) {
        KeyboardMode.ALPHA -> when (lang) {
            KeyboardLanguage.ENGLISH -> english(numberRow)
            KeyboardLanguage.BANGLA -> bangla(numberRow)
            KeyboardLanguage.ARABIC -> arabic(numberRow)
        }
        KeyboardMode.SYMBOLS -> symbols(lang)
        KeyboardMode.SYMBOLS_2 -> symbols2(lang)
        KeyboardMode.NUMBER -> numberPad(phone = false)
        KeyboardMode.PHONE -> numberPad(phone = true)
    }

    // ---------- shared rows ----------
    private fun numberRowFor(lang: KeyboardLanguage): List<Key> {
        val digits = nativeDigits(lang)
        return digits.mapIndexed { i, d ->
            if (lang == KeyboardLanguage.ENGLISH) ch(d) else ch(d, long = WESTERN_DIGITS[i])
        }
    }

    private fun bottomRow(total: Float, lang: KeyboardLanguage, alphaPage: Boolean): List<Key> {
        val modeKey = if (alphaPage) {
            val label = when (lang) {
                KeyboardLanguage.ENGLISH -> "?123"
                KeyboardLanguage.BANGLA -> "?১২৩"
                KeyboardLanguage.ARABIC -> "?١٢٣"
            }
            Key(KeyType.MODE_SYMBOLS, label = label, width = 1.5f)
        } else {
            val label = when (lang) {
                KeyboardLanguage.ENGLISH -> "ABC"
                KeyboardLanguage.BANGLA -> "অআক"
                KeyboardLanguage.ARABIC -> "أبج"
            }
            Key(KeyType.MODE_ALPHA, label = label, width = 1.5f)
        }
        val comma = when (lang) {
            KeyboardLanguage.ARABIC -> ch("،", long = ",")
            else -> ch(",", long = ";")
        }
        val period = when (lang) {
            KeyboardLanguage.ENGLISH -> ch(".", long = "?")
            KeyboardLanguage.BANGLA -> ch("।", long = ".")
            KeyboardLanguage.ARABIC -> ch(".", long = "؟")
        }
        val fixed = 1.5f + 1f + 1f + 1f + 1f + 1.5f
        val spaceWidth = (total - fixed).coerceAtLeast(3f)
        return listOf(
            modeKey,
            Key(KeyType.EMOJI),
            Key(KeyType.LANGUAGE),
            comma,
            Key(KeyType.SPACE, output = " ", width = spaceWidth),
            period,
            Key(KeyType.ENTER, width = 1.5f),
        )
    }

    // ---------- English ----------
    private fun english(numberRow: Boolean): KeyboardLayout {
        val r1 = "qwertyuiop".map { it.toString() }
        val r2 = "asdfghjkl".map { it.toString() }
        val r3 = "zxcvbnm".map { it.toString() }
        val r2Long = listOf("@", "#", "$", "_", "&", "-", "+", "(", ")")
        val r3Long = listOf("*", "\"", "'", ":", ";", "!", "?")

        val rows = mutableListOf<List<Key>>()
        if (numberRow) rows += numberRowFor(KeyboardLanguage.ENGLISH)
        rows += r1.mapIndexed { i, c -> latin(c, if (numberRow) null else WESTERN_DIGITS[i]) }
        rows += r2.mapIndexed { i, c -> latin(c, r2Long[i]) }
        rows += listOf(shiftKey(1.5f)) + r3.mapIndexed { i, c -> latin(c, r3Long[i]) } + backspace(1.5f)
        rows += bottomRow(10f, KeyboardLanguage.ENGLISH, alphaPage = true)
        return KeyboardLayout("en_alpha_$numberRow", rows)
    }

    // ---------- Bangla (Probhat-style: Shift gives the aspirated / long form) ----------
    private fun bangla(numberRow: Boolean): KeyboardLayout {
        val r1 = listOf(
            "দ" to "ধ", "ূ" to "ঊ", "ী" to "ঈ", "র" to "ড়", "ট" to "ঠ", "এ" to "ঐ",
            "ু" to "উ", "ি" to "ই", "ও" to "ঔ", "প" to "ফ", "ে" to "ৈ",
        )
        val r2 = listOf(
            "া" to "অ", "স" to "ষ", "ড" to "ঢ", "ত" to "থ", "গ" to "ঘ", "হ" to "ঃ",
            "জ" to "ঝ", "ক" to "খ", "ল" to "ং", "্" to "ঞ", "ো" to "ৌ",
        )
        val r3 = listOf(
            "য়" to "য", "শ" to "ঢ়", "চ" to "ছ", "আ" to "ঋ",
            "ব" to "ভ", "ন" to "ণ", "ম" to "ঙ", "ৃ" to "ৎ",
        )
        val rows = mutableListOf<List<Key>>()
        if (numberRow) rows += numberRowFor(KeyboardLanguage.BANGLA)
        rows += r1.mapIndexed { i, (n, s) ->
            ch(n, s, long = if (!numberRow && i < 10) BANGLA_DIGITS[i] else null)
        }
        rows += r2.map { (n, s) -> ch(n, s, long = if (n == "্") "ঁ" else null) }
        rows += listOf(shiftKey(1.5f)) + r3.map { (n, s) -> ch(n, s) } + backspace(1.5f)
        rows += bottomRow(11f, KeyboardLanguage.BANGLA, alphaPage = true)
        return KeyboardLayout("bn_alpha_$numberRow", rows)
    }

    // ---------- Arabic (Shift page: harakat, hamza forms and punctuation) ----------
    private fun harakah(mark: String) = "ـ$mark" // drawn on a tatweel so the mark is visible

    private fun arabic(numberRow: Boolean): KeyboardLayout {
        val r1 = listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج")
        val r1Shift = listOf("َ", "ً", "ُ", "ٌ", "ِ", "ٍ", "ّ", "ْ", "ـ", "«", "»")
        val r2 = listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط")
        val r2Shift = listOf("أ", "إ", "آ", "ئ", "ؤ", "ء", "لا", "ى", "ة", "ٱ", "؛")
        val r3 = listOf("ذ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ظ", "د")
        val r3Shift = listOf("؟", "!", ":", "\"", "'", "(", ")", "-", "،", "…")
        val r2Long = mapOf("ي" to "ئ", "ل" to "لا", "ا" to "أ", "ه" to "ة")
        val r3Long = mapOf("ء" to "ئ", "و" to "ؤ", "ى" to "ئ", "ر" to "ز")

        val rows = mutableListOf<List<Key>>()
        if (numberRow) rows += numberRowFor(KeyboardLanguage.ARABIC)
        rows += r1.mapIndexed { i, c ->
            val s = r1Shift[i]
            val isMark = s.length == 1 && s[0] in 'ً'..'ْ'
            ch(
                c, s,
                long = if (!numberRow && i < 10) ARABIC_DIGITS[i] else (if (c == "ه") "ة" else null),
                shiftLabel = if (isMark) harakah(s) else s,
            )
        }
        rows += r2.mapIndexed { i, c -> ch(c, r2Shift[i], long = r2Long[c]) }
        rows += listOf(shiftKey(1f)) + r3.mapIndexed { i, c -> ch(c, r3Shift[i], long = r3Long[c]) } + backspace(1f)
        rows += bottomRow(12f, KeyboardLanguage.ARABIC, alphaPage = true)
        return KeyboardLayout("ar_alpha_$numberRow", rows)
    }

    // ---------- Symbols ----------
    private fun symbols(lang: KeyboardLanguage): KeyboardLayout {
        val native = nativeDigits(lang)
        val row1 = WESTERN_DIGITS.mapIndexed { i, d ->
            if (lang == KeyboardLanguage.ENGLISH) ch(d) else ch(d, long = native[i])
        }
        val currency = if (lang == KeyboardLanguage.BANGLA) ch("৳", long = "$") else ch("$", long = "€")
        val row2 = listOf(ch("@"), ch("#"), currency, ch("_"), ch("&"), ch("-"), ch("+"), ch("("), ch(")"), ch("/"))
        val question = if (lang == KeyboardLanguage.ARABIC) ch("؟", long = "?") else ch("?", long = "¿")
        val semicolon = if (lang == KeyboardLanguage.ARABIC) ch("؛", long = ";") else ch(";")
        val row3 = listOf(Key(KeyType.MODE_SYMBOLS_2, label = "=\\<", width = 1.5f)) +
            listOf(ch("*"), ch("\""), ch("'"), ch(":"), semicolon, ch("!", long = "¡"), question) +
            backspace(1.5f)
        return KeyboardLayout(
            "sym_${lang.code}",
            listOf(row1, row2, row3, bottomRow(10f, lang, alphaPage = false))
        )
    }

    private fun symbols2(lang: KeyboardLanguage): KeyboardLayout {
        val row1 = listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆").map { ch(it) }
        val row2 = listOf("£", "¢", "€", "¥", "^", "°", "=", "{", "}", "\\").map { ch(it) }
        val row3 = listOf(Key(KeyType.MODE_SYMBOLS, label = "?123", width = 1.5f)) +
            listOf("%", "©", "®", "™", "✓", "[", "]").map { ch(it) } +
            backspace(1.5f)
        return KeyboardLayout(
            "sym2_${lang.code}",
            listOf(row1, row2, row3, bottomRow(10f, lang, alphaPage = false))
        )
    }

    // ---------- Number / phone pad (always Western digits so apps can parse them) ----------
    private fun numberPad(phone: Boolean): KeyboardLayout {
        val space = Key(KeyType.SPACE, output = " ", label = "␣")
        val rows = listOf(
            listOf(ch("1"), ch("2"), ch("3"), if (phone) ch("+") else ch("-")),
            listOf(ch("4"), ch("5"), ch("6"), space),
            listOf(ch("7"), ch("8"), ch("9"), backspace(1f)),
            if (phone) listOf(ch("*", long = "("), ch("0", long = "+"), ch("#", long = ")"), Key(KeyType.ENTER))
            else listOf(ch(","), ch("0"), ch("."), Key(KeyType.ENTER)),
        )
        return KeyboardLayout(if (phone) "phone" else "number", rows)
    }
}
