package com.rayean.aikeyboard.setup

import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.provider.Settings
import android.view.inputmethod.InputMethodManager

/** Checks whether Rayean AI Keyboard is enabled and selected in Android's input settings. */
object ImeStatus {

    fun isEnabled(context: Context): Boolean {
        val imm = context.getSystemService(InputMethodManager::class.java) ?: return false
        return imm.enabledInputMethodList.any { it.packageName == context.packageName }
    }

    fun isDefault(context: Context): Boolean {
        val imm = context.getSystemService(InputMethodManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && imm != null) {
            return imm.currentInputMethodInfo?.packageName == context.packageName
        }
        val id = Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return ComponentName.unflattenFromString(id)?.packageName == context.packageName
    }
}
