package com.rayean.aikeyboard.data

import com.google.mlkit.nl.translate.TranslateLanguage

/**
 * The three typing languages supported by Rayean AI Keyboard.
 *
 * @param code         short code stored in preferences and sent to the AI backend
 * @param keyLabel     label shown on the language-switch key
 * @param displayName  native name shown on the space bar
 * @param speechTag    default BCP-47 tag for Android speech recognition
 * @param mlKitCode    ML Kit on-device translation language
 */
enum class KeyboardLanguage(
    val code: String,
    val keyLabel: String,
    val displayName: String,
    val englishName: String,
    val speechTag: String,
    val mlKitCode: String,
) {
    ENGLISH("en", "EN", "English", "English", "en-US", TranslateLanguage.ENGLISH),
    BANGLA("bn", "বাং", "বাংলা", "Bangla", "bn-BD", TranslateLanguage.BENGALI),
    ARABIC("ar", "عربي", "العربية", "Arabic", "ar-SA", TranslateLanguage.ARABIC);

    companion object {
        fun fromCode(code: String?): KeyboardLanguage? = entries.firstOrNull { it.code == code }
    }
}
