package com.rayean.aikeyboard.translate

import com.rayean.aikeyboard.data.KeyboardLanguage
import com.rayean.aikeyboard.data.KeyboardLanguage.ARABIC
import com.rayean.aikeyboard.data.KeyboardLanguage.BANGLA
import com.rayean.aikeyboard.data.KeyboardLanguage.ENGLISH

/** The six supported translation directions. */
enum class TranslationDirection(val from: KeyboardLanguage, val to: KeyboardLanguage) {
    BN_EN(BANGLA, ENGLISH),
    EN_BN(ENGLISH, BANGLA),
    AR_BN(ARABIC, BANGLA),
    BN_AR(BANGLA, ARABIC),
    EN_AR(ENGLISH, ARABIC),
    AR_EN(ARABIC, ENGLISH);

    /** Chip label, e.g. "বাংলা → English". */
    val label: String get() = "${from.displayName} → ${to.displayName}"

    companion object {
        fun fromName(name: String?): TranslationDirection = entries.firstOrNull { it.name == name } ?: BN_EN
    }
}
