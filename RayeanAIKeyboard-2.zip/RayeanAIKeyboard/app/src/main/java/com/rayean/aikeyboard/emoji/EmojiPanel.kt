package com.rayean.aikeyboard.emoji

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.rayean.aikeyboard.R
import com.rayean.aikeyboard.keyboard.KeyboardTheme

/** Emoji picker shown in place of the keys when the emoji key is tapped. */
@SuppressLint("ViewConstructor")
class EmojiPanel(
    context: Context,
    private val callback: Callback,
) : LinearLayout(context) {

    interface Callback {
        fun onEmojiSelected(emoji: String)
        fun onEmojiBackspace()
        fun onEmojiPanelClosed()
        fun recentEmojis(): List<String>
    }

    private val dp = resources.displayMetrics.density
    private val grid = RecyclerView(context)
    private val adapter = EmojiAdapter()
    private val tabs = LinearLayout(context).apply { orientation = HORIZONTAL }
    private val abcButton = TextView(context)
    private val backspaceButton = ImageView(context)
    private val bottomBar = LinearLayout(context)
    private var theme: KeyboardTheme = KeyboardTheme.LIGHT
    private var selectedTab = 0
    private val handler = Handler(Looper.getMainLooper())

    init {
        orientation = VERTICAL

        grid.layoutManager = GridLayoutManager(context, COLUMNS)
        grid.adapter = adapter
        grid.overScrollMode = View.OVER_SCROLL_NEVER
        addView(grid, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        bottomBar.orientation = HORIZONTAL
        bottomBar.gravity = Gravity.CENTER_VERTICAL
        addView(bottomBar, LayoutParams(LayoutParams.MATCH_PARENT, (46 * dp).toInt()))

        abcButton.text = context.getString(R.string.emoji_abc)
        abcButton.gravity = Gravity.CENTER
        abcButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        abcButton.setOnClickListener { callback.onEmojiPanelClosed() }
        bottomBar.addView(abcButton, LayoutParams((60 * dp).toInt(), LayoutParams.MATCH_PARENT))

        val scroll = HorizontalScrollView(context)
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(tabs, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        bottomBar.addView(scroll, LayoutParams(0, LayoutParams.MATCH_PARENT, 1f))

        backspaceButton.setImageResource(R.drawable.ic_backspace)
        backspaceButton.scaleType = ImageView.ScaleType.CENTER_INSIDE
        backspaceButton.setPadding((16 * dp).toInt(), (11 * dp).toInt(), (16 * dp).toInt(), (11 * dp).toInt())
        backspaceButton.contentDescription = context.getString(R.string.cd_backspace)
        backspaceButton.setOnTouchListener(RepeatTouch { callback.onEmojiBackspace() })
        bottomBar.addView(backspaceButton, LayoutParams((60 * dp).toInt(), LayoutParams.MATCH_PARENT))

        buildTabs()
    }

    /** Call when the panel is shown: refreshes recents and picks the first useful tab. */
    fun onShown() {
        val hasRecents = callback.recentEmojis().isNotEmpty()
        selectTab(if (hasRecents) 0 else 1)
    }

    fun applyTheme(t: KeyboardTheme) {
        theme = t
        setBackgroundColor(t.background)
        bottomBar.setBackgroundColor(t.functionKey)
        abcButton.setTextColor(t.keyText)
        backspaceButton.setColorFilter(t.keyText)
        updateTabStyles()
        adapter.notifyDataSetChanged()
    }

    private fun buildTabs() {
        tabs.removeAllViews()
        val icons = listOf(EmojiData.RECENT_ICON) + EmojiData.categories.map { it.icon }
        icons.forEachIndexed { index, icon ->
            val tv = TextView(context)
            tv.text = icon
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f)
            tv.setOnClickListener { selectTab(index) }
            tabs.addView(tv, LayoutParams((46 * dp).toInt(), LayoutParams.MATCH_PARENT))
        }
    }

    private fun selectTab(index: Int) {
        selectedTab = index
        val items = if (index == 0) callback.recentEmojis() else EmojiData.categories[index - 1].emojis
        adapter.submit(items)
        grid.scrollToPosition(0)
        updateTabStyles()
    }

    private fun updateTabStyles() {
        for (i in 0 until tabs.childCount) {
            val v = tabs.getChildAt(i)
            v.background = if (i == selectedTab) GradientDrawable().apply {
                cornerRadius = 10 * dp
                setColor(theme.keyPressed)
            } else null
        }
    }

    private inner class EmojiAdapter : RecyclerView.Adapter<EmojiAdapter.Holder>() {
        private var items: List<String> = emptyList()

        @SuppressLint("NotifyDataSetChanged")
        fun submit(list: List<String>) {
            items = list
            notifyDataSetChanged()
        }

        inner class Holder(val text: TextView) : RecyclerView.ViewHolder(text)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val tv = TextView(parent.context)
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            tv.layoutParams = RecyclerView.LayoutParams(RecyclerView.LayoutParams.MATCH_PARENT, (48 * dp).toInt())
            return Holder(tv)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val emoji = items[position]
            holder.text.text = emoji
            holder.text.setTextColor(theme.keyText)
            holder.text.setOnClickListener { callback.onEmojiSelected(emoji) }
        }

        override fun getItemCount() = items.size
    }

    /** Repeats an action while the view is held down (used for Backspace). */
    private inner class RepeatTouch(private val action: () -> Unit) : View.OnTouchListener {
        private val repeat = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50L)
            }
        }

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    action()
                    v.isPressed = true
                    handler.postDelayed(repeat, 400L)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    handler.removeCallbacks(repeat)
                }
            }
            return true
        }
    }

    private companion object {
        const val COLUMNS = 8
    }
}
