package com.rayean.aikeyboard.setup

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.rayean.aikeyboard.R
import com.rayean.aikeyboard.settings.SettingsActivity
import com.rayean.aikeyboard.voice.VoicePermission

/**
 * First-time setup:
 *  1. Enable Rayean AI Keyboard (opens Android's keyboard list)
 *  2. Select it as the current keyboard (opens the system keyboard picker)
 *  3. Start typing (test field + microphone permission)
 */
class SetupActivity : AppCompatActivity() {

    private lateinit var step1Card: View
    private lateinit var step2Card: View
    private lateinit var step3Card: View
    private lateinit var step1Done: ImageView
    private lateinit var step2Done: ImageView
    private lateinit var step1Button: Button
    private lateinit var step2Button: Button
    private lateinit var micButton: Button
    private lateinit var tryInput: EditText

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        step1Card = findViewById(R.id.step1_card)
        step2Card = findViewById(R.id.step2_card)
        step3Card = findViewById(R.id.step3_card)
        step1Done = findViewById(R.id.step1_done)
        step2Done = findViewById(R.id.step2_done)
        step1Button = findViewById(R.id.step1_button)
        step2Button = findViewById(R.id.step2_button)
        micButton = findViewById(R.id.mic_button)
        tryInput = findViewById(R.id.try_input)

        step1Button.setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        step2Button.setOnClickListener {
            getSystemService(InputMethodManager::class.java)?.showInputMethodPicker()
        }
        micButton.setOnClickListener {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        findViewById<Button>(R.id.settings_button).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // The keyboard picker is a dialog, so onResume is not called when it closes.
        if (hasFocus) refresh()
    }

    private fun refresh() {
        val enabled = ImeStatus.isEnabled(this)
        val selected = enabled && ImeStatus.isDefault(this)

        step1Done.visibility = if (enabled) View.VISIBLE else View.GONE
        step1Button.visibility = if (enabled) View.GONE else View.VISIBLE
        step1Card.alpha = if (enabled) 0.7f else 1f

        step2Card.alpha = if (!enabled) 0.45f else if (selected) 0.7f else 1f
        step2Button.isEnabled = enabled
        step2Button.visibility = if (selected) View.GONE else View.VISIBLE
        step2Done.visibility = if (selected) View.VISIBLE else View.GONE

        step3Card.alpha = if (selected) 1f else 0.45f
        tryInput.isEnabled = selected

        val micGranted = VoicePermission.isGranted(this)
        micButton.isEnabled = !micGranted
        micButton.text = getString(if (micGranted) R.string.setup_mic_allowed else R.string.setup_allow_mic)
    }
}
