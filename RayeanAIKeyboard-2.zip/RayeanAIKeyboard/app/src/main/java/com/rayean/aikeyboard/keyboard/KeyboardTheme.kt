package com.rayean.aikeyboard.keyboard

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

/** Colors used by the keyboard, toolbar and emoji panel. */
data class KeyboardTheme(
    val id: String,
    val background: Int,
    val key: Int,
    val keyPressed: Int,
    val functionKey: Int,
    val functionKeyPressed: Int,
    val keyText: Int,
    val hintText: Int,
    val accent: Int,
    val onAccent: Int,
    val toolbarIcon: Int,
    val keyShadow: Int,
) {
    companion object {
        private fun c(hex: String) = Color.parseColor(hex)

        val LIGHT = KeyboardTheme(
            id = "light",
            background = c("#E8EBEF"), key = c("#FFFFFF"), keyPressed = c("#C9D1DA"),
            functionKey = c("#C5CCD5"), functionKeyPressed = c("#A9B3BF"),
            keyText = c("#1F2328"), hintText = c("#6B7280"),
            accent = c("#2563EB"), onAccent = c("#FFFFFF"), toolbarIcon = c("#374151"),
            keyShadow = c("#33000000"),
        )
        val DARK = KeyboardTheme(
            id = "dark",
            background = c("#1C1D21"), key = c("#3A3C42"), keyPressed = c("#56585F"),
            functionKey = c("#2A2C31"), functionKeyPressed = c("#45474D"),
            keyText = c("#F1F2F4"), hintText = c("#9CA3AF"),
            accent = c("#4C8DFF"), onAccent = c("#FFFFFF"), toolbarIcon = c("#D1D5DB"),
            keyShadow = c("#66000000"),
        )
        val MIDNIGHT = KeyboardTheme(
            id = "midnight",
            background = c("#000000"), key = c("#1A1A1A"), keyPressed = c("#333333"),
            functionKey = c("#0E0E0E"), functionKeyPressed = c("#2A2A2A"),
            keyText = c("#FFFFFF"), hintText = c("#8A8A8A"),
            accent = c("#00BFA5"), onAccent = c("#000000"), toolbarIcon = c("#E0E0E0"),
            keyShadow = c("#00000000"),
        )
        val OCEAN = KeyboardTheme(
            id = "ocean",
            background = c("#0B2545"), key = c("#16365F"), keyPressed = c("#22508A"),
            functionKey = c("#0F2C52"), functionKeyPressed = c("#1D4577"),
            keyText = c("#EEF4FB"), hintText = c("#8DA9C4"),
            accent = c("#3FA7D6"), onAccent = c("#0B2545"), toolbarIcon = c("#CFE0F0"),
            keyShadow = c("#55000000"),
        )
        val SAND = KeyboardTheme(
            id = "sand",
            background = c("#EFE8DE"), key = c("#FFFCF7"), keyPressed = c("#E2D6C5"),
            functionKey = c("#DDD2C2"), functionKeyPressed = c("#CBBDA9"),
            keyText = c("#3B2F24"), hintText = c("#8B7B69"),
            accent = c("#C2410C"), onAccent = c("#FFFFFF"), toolbarIcon = c("#5B4A3A"),
            keyShadow = c("#26000000"),
        )

        fun resolve(context: Context, id: String): KeyboardTheme = when (id) {
            "light" -> LIGHT
            "dark" -> DARK
            "midnight" -> MIDNIGHT
            "ocean" -> OCEAN
            "sand" -> SAND
            else -> {
                val night = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
                if (night == Configuration.UI_MODE_NIGHT_YES) DARK else LIGHT
            }
        }
    }
}
