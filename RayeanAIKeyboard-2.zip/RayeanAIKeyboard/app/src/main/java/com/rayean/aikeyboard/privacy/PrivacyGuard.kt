package com.rayean.aikeyboard.privacy

import android.text.InputType
import android.view.inputmethod.EditorInfo
import java.util.Locale

/**
 * Decides which features may run in the current text field.
 *
 * Rule: password, PIN, OTP and payment-card fields never leave the device — AI Fix,
 * AI translation and voice typing are switched off there. As a second safety net,
 * [containsSensitiveData] blocks text that looks like a card number or a one-time code
 * even when it is typed into an ordinary field.
 */
object PrivacyGuard {

    enum class Level {
        /** Normal text: every feature allowed. */
        NORMAL,
        /** Incognito / no-learning field: no AI or translation, voice still allowed. */
        INCOGNITO,
        /** Password, PIN, OTP, card or other numeric field: no AI, no translation, no voice. */
        PRIVATE,
    }

    private val SENSITIVE_HINT_WORDS = listOf(
        // English
        "password", "passcode", "passwd", "pin", "otp", "one-time", "one time", "verification code",
        "security code", "cvv", "cvc", "card number", "credit card", "debit card", "expiry", "iban", "ssn",
        // Bangla
        "পাসওয়ার্ড", "পিন", "ওটিপি", "কার্ড নম্বর", "যাচাইকরণ কোড",
        // Arabic
        "كلمة المرور", "كلمة السر", "الرقم السري", "رمز التحقق", "رمز التأكيد", "رقم البطاقة",
    )

    fun classify(info: EditorInfo?): Level {
        if (info == null) return Level.PRIVATE
        val type = info.inputType
        val cls = type and InputType.TYPE_MASK_CLASS
        val variation = type and InputType.TYPE_MASK_VARIATION

        when (cls) {
            InputType.TYPE_CLASS_TEXT -> {
                if (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
                ) return Level.PRIVATE
            }
            // Numeric fields are where PINs, OTPs and card numbers live.
            InputType.TYPE_CLASS_NUMBER, InputType.TYPE_CLASS_PHONE -> return Level.PRIVATE
            InputType.TYPE_CLASS_DATETIME -> return Level.INCOGNITO
            InputType.TYPE_NULL -> return Level.INCOGNITO
        }

        val hints = buildString {
            append(info.hintText ?: "").append(' ')
            append(info.label ?: "").append(' ')
            append(info.fieldName ?: "").append(' ')
            append(info.privateImeOptions ?: "")
        }.lowercase(Locale.ROOT)
        if (SENSITIVE_HINT_WORDS.any { word -> containsWord(hints, word) }) return Level.PRIVATE

        if (info.imeOptions and EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING != 0) return Level.INCOGNITO
        return Level.NORMAL
    }

    private fun containsWord(haystack: String, word: String): Boolean {
        if (word.length > 3) return haystack.contains(word)
        // Short words like "pin"/"otp" must stand alone ("spinner" is not a PIN field).
        return Regex("(^|[^\\p{L}])${Regex.escape(word)}([^\\p{L}]|$)").containsMatchIn(haystack)
    }

    private val CARD_CANDIDATE = Regex("(?<!\\d)(?:\\d[ -]?){12,18}\\d(?!\\d)")
    private val CODE_KEYWORDS = Regex(
        "(\\b(otp|one[- ]time|verification|code|passcode|password|pin|cvv|cvc)\\b|" +
            "ওটিপি|কোড|পাসওয়ার্ড|পিন|رمز|كلمة المرور|كلمة السر)",
        RegexOption.IGNORE_CASE,
    )
    private val SHORT_CODE = Regex("(?<!\\d)\\d{4,8}(?!\\d)")

    /** True when the text looks like it contains a payment-card number or a one-time code / PIN. */
    fun containsSensitiveData(text: String): Boolean {
        val ascii = toAsciiDigits(text)
        for (m in CARD_CANDIDATE.findAll(ascii)) {
            val digits = m.value.filter { it.isDigit() }
            if (digits.length in 13..19 && luhnValid(digits)) return true
        }
        if (CODE_KEYWORDS.containsMatchIn(ascii) && SHORT_CODE.containsMatchIn(ascii)) return true
        return false
    }

    /** Converts Bangla (০-৯) and Arabic-Indic (٠-٩, ۰-۹) digits to 0-9 for detection. */
    private fun toAsciiDigits(s: String): String = buildString(s.length) {
        for (c in s) {
            append(
                when (c) {
                    in '০'..'৯' -> '0' + (c - '০')
                    in '٠'..'٩' -> '0' + (c - '٠')
                    in '۰'..'۹' -> '0' + (c - '۰')
                    else -> c
                }
            )
        }
    }

    private fun luhnValid(digits: String): Boolean {
        var sum = 0
        var double = false
        for (i in digits.indices.reversed()) {
            var d = digits[i] - '0'
            if (double) {
                d *= 2
                if (d > 9) d -= 9
            }
            sum += d
            double = !double
        }
        return sum % 10 == 0
    }
}
