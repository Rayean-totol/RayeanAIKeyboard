package com.rayean.aikeyboard

import android.app.Application
import androidx.preference.PreferenceManager

class RayeanApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Make sure defaults from preferences.xml exist before the keyboard reads them.
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
    }
}
