# Rayean AI backend (NEEDS_API)

AI Fix and AI translation need a language model. The keyboard never contains an API key — it calls this small server, and the server calls the Claude API.

On-device translation (ML Kit) and voice typing (Android SpeechRecognizer) work **without** this backend.

## API used by the keyboard

| Method | Path | Body | Response |
|---|---|---|---|
| `POST` | `/v1/fix` | `{"text": "I am go market", "keyboard_language": "en"}` | `{"text": "I am going to the market."}` |
| `POST` | `/v1/translate` | `{"text": "...", "source": "bn", "target": "en"}` | `{"text": "..."}` |
| `GET` | `/health` | – | `{"ok": true}` |

Language codes: `en`, `bn`, `ar`. Max 4000 characters per request.
If `APP_TOKEN` is set, every request must send `Authorization: Bearer <APP_TOKEN>`.

## Run it

Requires Node.js 18 or newer. No npm packages are needed.

```bash
cd backend
export ANTHROPIC_API_KEY=sk-ant-...      # from https://platform.claude.com
export APP_TOKEN=$(openssl rand -hex 24) # optional but recommended
npm start                                # listens on :8787
npm test                                 # offline test with a mock API
```

With Docker:

```bash
docker build -t rayean-ai-backend .
docker run -p 8787:8787 -e ANTHROPIC_API_KEY=sk-ant-... -e APP_TOKEN=... rayean-ai-backend
```

Deploy it anywhere that runs Node or Docker over **HTTPS** (Render, Railway, Fly.io, Google Cloud Run, a VPS behind Caddy/Nginx…).

## Connect the keyboard

Either:

- On the phone: **Rayean AI Keyboard → Settings → AI backend URL** = `https://your-server…`, and **AI backend app token** = your `APP_TOKEN`. Then tap **Test AI backend**.
- Or at build time: set `rayean.aiBackendUrl=https://your-server…` in `gradle.properties`.

For local testing on the Android emulator use `http://10.0.2.2:8787` (plain HTTP is only allowed for 10.0.2.2 / localhost).

## Privacy

- The keyboard never sends password, PIN, OTP, card-number or other numeric fields, or incognito fields.
- It also refuses to send text that looks like a payment card number or a one-time code.
- This server never logs or stores request text; only errors (status and message) are logged.

## Changing the model or provider

Set `AI_MODEL` to another Claude model ID. To use a different provider, replace `callClaude()` in `server.js` — the keyboard only depends on the three endpoints above.
