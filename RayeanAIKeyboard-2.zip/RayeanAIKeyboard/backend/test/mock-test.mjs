// Offline test: runs server.js against a mock Claude API and checks every endpoint.
// Usage: npm test
import http from "node:http";
import { spawn } from "node:child_process";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const received = [];

// --- mock Anthropic Messages API ---
const mock = http.createServer((req, res) => {
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", () => {
    const json = JSON.parse(body);
    received.push({ headers: req.headers, json });
    const input = json.messages[0].content;
    let reply = "?";
    if (input.includes("I am go market")) reply = "I am going to the market.";
    else if (input.includes("ami ajke dokane jabo")) reply = "আমি আজকে দোকানে যাব।";
    else if (input.includes("How are you")) reply = "\"আপনি কেমন আছেন?\"";
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ content: [{ type: "text", text: reply }] }));
  });
});
await new Promise((r) => mock.listen(0, r));
const mockPort = mock.address().port;

// --- start the real server ---
const port = 18000 + Math.floor(Math.random() * 1000);
const server = spawn(process.execPath, [path.join(here, "..", "server.js")], {
  env: {
    ...process.env,
    PORT: String(port),
    ANTHROPIC_API_KEY: "test-key",
    ANTHROPIC_BASE_URL: `http://127.0.0.1:${mockPort}`,
    APP_TOKEN: "secret-token",
  },
  stdio: ["ignore", "pipe", "pipe"],
});
let logs = "";
server.stdout.on("data", (d) => (logs += d));
server.stderr.on("data", (d) => (logs += d));
await new Promise((r) => setTimeout(r, 600));

const base = `http://127.0.0.1:${port}`;
const auth = { Authorization: "Bearer secret-token", "content-type": "application/json" };
const post = (p, body, headers = auth) =>
  fetch(base + p, { method: "POST", headers, body: JSON.stringify(body) });

try {
  // health
  let r = await fetch(base + "/health", { headers: auth });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).ok, true);

  // auth required
  r = await post("/v1/fix", { text: "x" }, { "content-type": "application/json" });
  assert.equal(r.status, 401);

  // English fix
  r = await post("/v1/fix", { text: "I am go market", keyboard_language: "en" });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).text, "I am going to the market.");

  // Banglish -> Bangla
  r = await post("/v1/fix", { text: "ami ajke dokane jabo", keyboard_language: "en" });
  assert.equal((await r.json()).text, "আমি আজকে দোকানে যাব।");

  // Translate (quotes stripped)
  r = await post("/v1/translate", { text: "How are you?", source: "en", target: "bn" });
  assert.equal(r.status, 200);
  assert.equal((await r.json()).text, "আপনি কেমন আছেন?");
  assert.match(received.at(-1).json.system, /from English to Bengali/);

  // Validation
  r = await post("/v1/translate", { text: "hi", source: "en", target: "en" });
  assert.equal(r.status, 400);
  r = await post("/v1/fix", { text: "" });
  assert.equal(r.status, 400);
  r = await post("/v1/fix", { text: "a".repeat(4001) });
  assert.equal(r.status, 413);

  // Upstream request shape
  const last = received[0];
  assert.equal(last.headers["x-api-key"], "test-key");
  assert.equal(last.headers["anthropic-version"], "2023-06-01");
  assert.equal(last.json.model, "claude-haiku-4-5-20251001");
  assert.ok(last.json.messages[0].content.includes("<text>"));

  // Privacy: user text must never be written to logs
  assert.ok(!logs.includes("I am go market"), "user text leaked into logs");
  assert.ok(!logs.includes("ami ajke"), "user text leaked into logs");

  console.log("All backend tests passed ✓");
} finally {
  server.kill();
  mock.close();
}
